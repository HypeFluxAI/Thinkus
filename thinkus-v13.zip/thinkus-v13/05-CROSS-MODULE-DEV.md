# 05 AI高管跨模块协作规范

> 当用户需求涉及前端+后端+数据库等多模块时，AI高管如何协作完成开发

---

## 1. 问题场景

用户说："帮我做一个用户登录功能"

这涉及：
- **前端**: 登录页面、表单验证、Token存储
- **后端**: 登录API、JWT生成、密码校验
- **数据库**: 用户表、Session表

**问题**: 如何确保AI生成的多模块代码能正确配合？

---

## 2. AI高管分工

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                         AI高管协作模型                                       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        Mike (PM)                                     │   │
│  │                      需求分析 + 总协调                               │   │
│  │                      生成接口契约                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                    ┌───────────────┼───────────────┐                       │
│                    ▼               ▼               ▼                       │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐           │
│  │   Elena (UX)     │ │  David (Tech)    │ │   Sam (DB)       │           │
│  │   前端开发       │ │   后端开发       │ │   数据库设计     │           │
│  │                  │ │                  │ │                  │           │
│  │  • 登录页面UI    │ │  • POST /login   │ │  • users表       │           │
│  │  • 表单验证      │ │  • JWT生成       │ │  • 索引设计      │           │
│  │  • 错误提示      │ │  • 密码校验      │ │                  │           │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘           │
│                    │               │               │                       │
│                    └───────────────┼───────────────┘                       │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        Kevin (QA)                                    │   │
│  │                      集成验证 + 一致性检查                           │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. 核心机制：接口契约

### 3.1 什么是接口契约

Mike在分析需求后，首先生成**接口契约**，所有AI高管必须遵循：

```typescript
// Mike生成的接口契约
interface InterfaceContract {
  feature: "用户登录";
  
  // API定义 - David必须遵循
  api: {
    path: "POST /api/auth/login";
    request: {
      email: string;
      password: string;
    };
    response: {
      token: string;
      user: { id: string; email: string; name: string; };
    };
    errors: ["INVALID_CREDENTIALS", "USER_NOT_FOUND"];
  };
  
  // 数据库定义 - Sam必须遵循
  database: {
    table: "users";
    fields: {
      id: "uuid PRIMARY KEY";
      email: "varchar(255) UNIQUE";
      password_hash: "varchar(255)";
      name: "varchar(100)";
    };
  };
  
  // 前端定义 - Elena必须遵循
  frontend: {
    page: "/login";
    formFields: ["email", "password"];
    storage: "localStorage.token";
    errorHandling: ["INVALID_CREDENTIALS", "USER_NOT_FOUND"];
  };
}
```

### 3.2 契约的作用

```
契约 = 各模块间的"合同"

✅ 前端知道要发什么参数、处理什么错误码
✅ 后端知道要接收什么参数、返回什么格式
✅ 数据库知道要建什么表、什么字段
✅ Kevin知道要验证什么
```

---

## 4. 完整协作流程

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Step 1: Mike 分析需求 + 生成契约                                           │
│  ════════════════════════════════                                           │
│                                                                              │
│  输入: "帮我做一个用户登录功能"                                             │
│                                                                              │
│  Mike分析:                                                                   │
│  • 涉及模块: 前端、后端、数据库                                             │
│  • 依赖关系: 数据库 → 后端 → 前端                                           │
│  • 生成接口契约 (API/DB/Frontend)                                           │
│                                                                              │
│  输出: InterfaceContract                                                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Step 2: 基于契约并行开发                                                   │
│  ════════════════════════                                                   │
│                                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐            │
│  │    Sam (DB)     │  │  David (后端)   │  │  Elena (前端)   │            │
│  │                 │  │                 │  │                 │            │
│  │ 拿到契约中的    │  │ 拿到契约中的    │  │ 拿到完整契约    │            │
│  │ database部分    │  │ api部分         │  │                 │            │
│  │                 │  │                 │  │                 │            │
│  │ 生成:           │  │ 生成:           │  │ 生成:           │            │
│  │ • migration     │  │ • 路由处理      │  │ • 登录页面      │            │
│  │ • schema        │  │ • JWT逻辑       │  │ • 表单组件      │            │
│  │                 │  │ • 错误处理      │  │ • API调用       │            │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘            │
│           │                   │                    │                       │
│           └───────────────────┴────────────────────┘                       │
│                    全部基于相同的契约                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Step 3: Kevin 集成验证                                                     │
│  ══════════════════════                                                     │
│                                                                              │
│  Kevin检查:                                                                  │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ ✓ 后端API路径 = 契约定义的路径?                                     │   │
│  │ ✓ 后端请求参数 = 契约定义的参数?                                    │   │
│  │ ✓ 后端响应格式 = 契约定义的格式?                                    │   │
│  │ ✓ 后端错误码 = 契约定义的错误码?                                    │   │
│  │ ✓ 前端表单字段 = 契约定义的字段?                                    │   │
│  │ ✓ 前端API调用 = 契约定义的路径?                                     │   │
│  │ ✓ 前端错误处理 = 契约定义的错误码?                                  │   │
│  │ ✓ 数据库字段 = 契约定义的字段?                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  发现问题:                                                                   │
│  ⚠️ "前端没有处理 USER_NOT_FOUND 错误码"                                   │
│  → 返回Elena修复                                                            │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Step 4: 修复 → 再验证 → 完成                                              │
│  ════════════════════════════                                               │
│                                                                              │
│  Elena修复: 添加USER_NOT_FOUND错误处理                                      │
│  Kevin再验证: ✅ 全部通过                                                   │
│  → 代码合并，功能完成                                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. 实现代码

### 5.1 Mike生成契约

```python
# services/ai_employees/mike_contract.py

class MikeContractGenerator:
    """Mike生成接口契约"""
    
    def generate_contract(self, requirement: str, project_context: dict) -> InterfaceContract:
        """分析需求，生成接口契约"""
        
        prompt = f"""分析以下需求，生成完整的接口契约：

需求: {requirement}
项目上下文: {project_context}

请输出JSON格式的接口契约，包含:

1. api: API定义
   - path: 请求路径 (如 "POST /api/auth/login")
   - request: 请求参数及类型
   - response: 成功响应格式
   - errors: 所有可能的错误码

2. database: 数据库定义
   - table: 表名
   - fields: 字段名及类型
   - indexes: 索引
   
3. frontend: 前端定义
   - page: 页面路径
   - formFields: 表单字段
   - apiCalls: 需要调用的API
   - errorHandling: 需要处理的错误码

确保:
- 前端formFields与API request参数一致
- 前端errorHandling覆盖所有API errors
- 数据库fields支持API所需的数据
"""
        
        response = self.ai.chat('mike_pm', prompt)
        return self._parse_contract(response.text)
```

### 5.2 各AI高管基于契约开发

```python
# services/ai_employees/contract_developer.py

class ContractBasedDeveloper:
    """基于契约开发"""
    
    def develop_backend(self, contract: InterfaceContract) -> str:
        """David基于契约开发后端"""
        
        prompt = f"""基于以下接口契约开发后端代码：

API契约:
- 路径: {contract.api['path']}
- 请求参数: {contract.api['request']}
- 响应格式: {contract.api['response']}
- 错误码: {contract.api['errors']}

数据库:
- 表: {contract.database['table']}
- 字段: {contract.database['fields']}

要求:
1. 严格按照契约定义实现
2. 请求参数必须完全匹配
3. 响应格式必须完全匹配
4. 必须实现所有错误码
5. 连接正确的数据库表

生成完整可运行的代码。"""
        
        return self.ai.chat('david_tech', prompt).text
    
    def develop_frontend(self, contract: InterfaceContract) -> str:
        """Elena基于契约开发前端"""
        
        prompt = f"""基于以下接口契约开发前端代码：

页面: {contract.frontend['page']}
表单字段: {contract.frontend['formFields']}

API调用:
- 路径: {contract.api['path']}
- 请求参数: {contract.api['request']}
- 响应格式: {contract.api['response']}
- 错误码: {contract.api['errors']}

要求:
1. 表单字段必须与API请求参数一致
2. 必须处理所有错误码并显示对应提示
3. 成功时按响应格式处理数据
4. Token存储到: {contract.frontend.get('storage', 'localStorage')}

生成完整的React组件代码。"""
        
        return self.ai.chat('elena_ux', prompt).text
    
    def develop_database(self, contract: InterfaceContract) -> str:
        """Sam基于契约设计数据库"""
        
        prompt = f"""基于以下契约创建数据库:

表: {contract.database['table']}
字段: {contract.database['fields']}
索引: {contract.database.get('indexes', [])}

生成migration文件。"""
        
        return self.ai.chat('sam_db', prompt).text
```

### 5.3 Kevin验证一致性

```python
# services/ai_employees/kevin_verifier.py

class KevinContractVerifier:
    """Kevin验证代码是否符合契约"""
    
    def verify(self, contract: InterfaceContract, code: Dict[str, str]) -> VerifyResult:
        """验证所有模块是否符合契约"""
        
        issues = []
        
        # 1. 验证后端
        backend_issues = self._verify_backend(contract, code.get('backend', ''))
        issues.extend(backend_issues)
        
        # 2. 验证前端
        frontend_issues = self._verify_frontend(contract, code.get('frontend', ''))
        issues.extend(frontend_issues)
        
        # 3. 验证一致性
        consistency_issues = self._verify_consistency(contract, code)
        issues.extend(consistency_issues)
        
        return VerifyResult(success=len(issues) == 0, issues=issues)
    
    def _verify_backend(self, contract, code) -> List[str]:
        """验证后端代码"""
        
        prompt = f"""检查后端代码是否符合契约：

契约:
- 路径: {contract.api['path']}
- 请求参数: {contract.api['request']}
- 响应格式: {contract.api['response']}
- 错误码: {contract.api['errors']}

代码:
{code}

检查并列出问题:
1. API路径是否正确?
2. 是否接收所有请求参数?
3. 响应格式是否匹配?
4. 是否实现所有错误码?

只输出发现的问题，没问题则输出空。"""
        
        result = self.ai.chat('kevin_qa', prompt)
        return self._parse_issues(result.text)
    
    def _verify_frontend(self, contract, code) -> List[str]:
        """验证前端代码"""
        
        prompt = f"""检查前端代码是否符合契约：

契约:
- 表单字段: {contract.frontend['formFields']}
- API路径: {contract.api['path']}
- 请求参数: {contract.api['request']}
- 错误码: {contract.api['errors']}

代码:
{code}

检查并列出问题:
1. 表单字段是否完整?
2. API调用路径是否正确?
3. 发送的参数是否匹配?
4. 是否处理所有错误码?

只输出发现的问题，没问题则输出空。"""
        
        result = self.ai.chat('kevin_qa', prompt)
        return self._parse_issues(result.text)
    
    def _verify_consistency(self, contract, code) -> List[str]:
        """验证前后端一致性"""
        
        prompt = f"""检查前后端代码的一致性：

后端代码:
{code.get('backend', '')}

前端代码:
{code.get('frontend', '')}

检查:
1. 前端发送的字段名 = 后端接收的字段名?
2. 前端处理的响应字段 = 后端返回的字段?
3. 数据类型是否匹配?

只输出发现的不一致，没问题则输出空。"""
        
        result = self.ai.chat('kevin_qa', prompt)
        return self._parse_issues(result.text)
```

### 5.4 完整工作流

```python
# services/workflow/cross_module_workflow.py

class CrossModuleWorkflow:
    """跨模块开发工作流"""
    
    def __init__(self):
        self.mike = MikeContractGenerator()
        self.developer = ContractBasedDeveloper()
        self.kevin = KevinContractVerifier()
    
    async def execute(self, requirement: str, project_id: str) -> Result:
        """执行跨模块开发"""
        
        # Step 1: Mike生成契约
        contract = self.mike.generate_contract(requirement, self._get_context(project_id))
        
        # Step 2: 通知用户契约内容 (可选确认)
        await self._notify_contract(project_id, contract)
        
        # Step 3: 并行开发
        code = {}
        
        # 数据库优先
        code['database'] = self.developer.develop_database(contract)
        
        # 后端和前端可以并行 (都基于契约)
        code['backend'] = self.developer.develop_backend(contract)
        code['frontend'] = self.developer.develop_frontend(contract)
        
        # Step 4: Kevin验证
        verify_result = self.kevin.verify(contract, code)
        
        # Step 5: 如有问题，修复
        attempts = 0
        while not verify_result.success and attempts < 3:
            code = await self._fix_issues(contract, code, verify_result.issues)
            verify_result = self.kevin.verify(contract, code)
            attempts += 1
        
        if not verify_result.success:
            return Result(success=False, error="无法修复所有问题", issues=verify_result.issues)
        
        # Step 6: 写入文件
        await self._write_files(project_id, code)
        
        return Result(success=True, files=list(code.keys()))
    
    async def _fix_issues(self, contract, code, issues) -> Dict[str, str]:
        """修复问题"""
        
        for issue in issues:
            if 'backend' in issue.lower() or 'api' in issue.lower():
                # 后端问题，让David修复
                code['backend'] = self._fix_backend(contract, code['backend'], issue)
            elif 'frontend' in issue.lower() or '前端' in issue.lower():
                # 前端问题，让Elena修复
                code['frontend'] = self._fix_frontend(contract, code['frontend'], issue)
        
        return code
```

---

## 6. 用户视角

用户看到的流程：

```
用户: "帮我做一个用户登录功能"

Mike: "好的，我来分析一下这个功能需要：
       - 前端：登录页面和表单
       - 后端：认证API
       - 数据库：用户表
       
       我已经生成了接口契约，现在各模块开始开发..."

[进度显示]
📦 数据库: Sam正在创建users表... ✅ 完成
🔧 后端: David正在开发登录API... ✅ 完成  
🎨 前端: Elena正在开发登录页面... ✅ 完成

Kevin: "正在验证各模块的一致性...
        ✅ API路径正确
        ✅ 参数匹配
        ⚠️ 发现问题：前端缺少USER_NOT_FOUND错误处理"

Elena: "已修复，添加了错误处理"

Kevin: "再次验证... ✅ 全部通过"

Mike: "登录功能开发完成！包含：
       - /login 登录页面
       - POST /api/auth/login 认证接口
       - users数据库表"
```

---

## 7. 关键点总结

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  1. 契约先行                                                                │
│     Mike先生成接口契约，定义各模块的"合同"                                  │
│     包括：API参数/响应、数据库Schema、前端要求                              │
│                                                                              │
│  2. 基于契约并行开发                                                        │
│     各AI高管拿到同一份契约                                                  │
│     独立开发，不需要等待其他模块                                            │
│     契约保证最终能对接上                                                    │
│                                                                              │
│  3. Kevin验证一致性                                                         │
│     检查每个模块是否遵循契约                                                │
│     检查模块间是否一致（字段名、类型、错误码）                              │
│     发现问题返回对应AI修复                                                  │
│                                                                              │
│  4. 自动修复循环                                                            │
│     问题 → 定位是哪个模块 → 该AI修复 → Kevin再验证                         │
│     最多尝试3次                                                             │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```
