# 03 核心功能

## 1. 功能清单

### Phase 1 (1月)
| 功能 | 描述 | 优先级 |
|------|------|--------|
| 计划先行 | 开发前展示计划，用户确认 | P0 |
| 版本追踪 | 变更历史，一键回滚 | P0 |
| 自动验证 | 构建/测试/规范检查 | P0 |

### Phase 2 (2月)
| 功能 | 描述 | 优先级 |
|------|------|--------|
| 上下文管理 | CodeIndexer + PromptBuilder | P0 |
| 检查点机制 | 阶段评估，允许重启 | P0 |
| GitHub集成 | 代码同步 | P1 |
| AI组件库 | ChatBot/ImageGen等 | P1 |

### Phase 3 (3月)
| 功能 | 描述 | 优先级 |
|------|------|--------|
| Stripe支付 | 一句话配置支付 | P1 |
| Figma导入 | 设计稿转代码 | P1 |

---

## 2. 计划先行

### 2.1 流程
```
用户: "帮我做一个任务管理工具"
         ↓
Mike(PM): 分析需求 → 生成计划
         ↓
展示计划卡片 (用户可调整)
         ↓
用户确认 → 开始执行
```

### 2.2 API

```go
// POST /api/v1/projects/:id/plan
type PlanRequest struct {
    Requirement string `json:"requirement"`
}

type PlanResponse struct {
    Plan Plan `json:"plan"`
}

type Plan struct {
    ID            string  `json:"id"`
    Phases        []Phase `json:"phases"`
    TechStack     TechStack `json:"tech_stack"`
    EstimatedMins int     `json:"estimated_minutes"`
}

type Phase struct {
    Name     string `json:"name"`
    Tasks    []Task `json:"tasks"`
    Optional bool   `json:"optional"`
}

type Task struct {
    ID         string `json:"id"`
    Title      string `json:"title"`
    Difficulty string `json:"difficulty"` // easy/medium/hard
    Minutes    int    `json:"minutes"`
}

// POST /api/v1/projects/:id/plan/confirm
type ConfirmRequest struct {
    PlanID        string   `json:"plan_id"`
    SelectedTasks []string `json:"selected_tasks"`
}
```

### 2.3 前端组件

```tsx
// components/PlanCard.tsx
export function PlanCard({ plan, onConfirm }) {
  const [selected, setSelected] = useState(new Set(
    plan.phases.flatMap(p => p.tasks.map(t => t.id))
  ));

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-semibold mb-4">📋 开发计划</h3>
      
      <div className="text-sm text-gray-500 mb-4">
        技术栈：{plan.techStack.frontend} + {plan.techStack.backend}
      </div>
      
      {plan.phases.map(phase => (
        <div key={phase.name} className="mb-4">
          <h4 className="font-medium">{phase.name}</h4>
          <div className="ml-4 mt-2">
            {phase.tasks.map(task => (
              <label key={task.id} className="flex items-center mb-1">
                <input
                  type="checkbox"
                  checked={selected.has(task.id)}
                  onChange={() => {
                    const next = new Set(selected);
                    next.has(task.id) ? next.delete(task.id) : next.add(task.id);
                    setSelected(next);
                  }}
                />
                <span className="ml-2">{task.title}</span>
                <span className="ml-2 text-xs text-gray-400">
                  {task.difficulty} · {task.minutes}min
                </span>
              </label>
            ))}
          </div>
        </div>
      ))}
      
      <div className="text-sm text-gray-500 mb-4">
        预计：{plan.estimatedMins} 分钟
      </div>
      
      <button
        onClick={() => onConfirm(Array.from(selected))}
        className="w-full bg-blue-500 text-white py-2 rounded"
      >
        确认开始
      </button>
    </div>
  );
}
```

---

## 3. 版本追踪

### 3.1 数据结构

```go
type Version struct {
    ID         string    `json:"id"`
    ProjectID  string    `json:"project_id"`
    Number     int       `json:"number"`
    Author     string    `json:"author"` // user/david_tech/elena_ux
    Summary    string    `json:"summary"`
    Changes    []Change  `json:"changes"`
    SnapshotID string    `json:"snapshot_id"`
    CreatedAt  time.Time `json:"created_at"`
}

type Change struct {
    FilePath   string `json:"file_path"`
    ChangeType string `json:"change_type"` // create/modify/delete
    LinesAdded int    `json:"lines_added"`
    LinesRemoved int  `json:"lines_removed"`
}
```

### 3.2 API

```go
// GET /api/v1/projects/:id/versions
// GET /api/v1/projects/:id/versions/:vid/diff
// POST /api/v1/projects/:id/versions/:vid/rollback
```

### 3.3 核心实现

```go
type VersionManager struct {
    store     VersionStore
    snapshots SnapshotStore
}

func (m *VersionManager) CreateVersion(projectID string, changes []Change, author string) (*Version, error) {
    // 1. 创建代码快照
    snapshotID, _ := m.snapshots.Create(projectID)
    
    // 2. 获取版本号
    last, _ := m.store.GetLatest(projectID)
    number := 1
    if last != nil {
        number = last.Number + 1
    }
    
    // 3. 生成摘要
    summary := m.generateSummary(changes)
    
    // 4. 保存
    version := &Version{
        ID: uuid.New().String(),
        ProjectID: projectID,
        Number: number,
        Author: author,
        Summary: summary,
        Changes: changes,
        SnapshotID: snapshotID,
        CreatedAt: time.Now(),
    }
    
    return version, m.store.Save(version)
}

func (m *VersionManager) Rollback(projectID, versionID string) error {
    version, _ := m.store.Get(versionID)
    return m.snapshots.Restore(projectID, version.SnapshotID)
}
```

---

## 4. GitHub集成

### 4.1 流程
```
1. 用户授权GitHub (OAuth)
2. 选择/创建仓库
3. 开启自动同步
4. 每次变更自动 commit + push
```

### 4.2 实现

```go
type GitHubIntegration struct {
    tokens map[string]string // userID -> token
}

func (g *GitHubIntegration) SyncChanges(projectID string, changes []Change, message string) error {
    config := g.getConfig(projectID)
    client := g.getClient(config.UserID)
    
    // 获取当前ref
    ref, _, _ := client.Git.GetRef(ctx, config.Owner, config.Repo, "refs/heads/main")
    
    // 创建commit (简化)
    // ...
    
    return nil
}
```

---

## 5. AI组件库

### 5.1 组件列表

| 组件 | 触发关键词 | 描述 |
|------|-----------|------|
| AIChatBot | 聊天、客服、FAQ | 智能客服 |
| AIImageGen | 生成图片、头像 | 图像生成 |
| AIContentGen | 生成文案、描述 | 内容生成 |
| AISearch | 智能搜索 | 语义搜索 |
| AIRecommend | 推荐、个性化 | 推荐系统 |

### 5.2 检测逻辑

```python
AI_COMPONENTS = {
    'chatbot': {
        'keywords': ['聊天', '客服', 'FAQ', '机器人'],
        'component': 'AIChatBot'
    },
    'image_gen': {
        'keywords': ['生成图片', '头像', 'AI画'],
        'component': 'AIImageGen'
    },
    # ...
}

def detect_ai_needs(requirement: str) -> list:
    detected = []
    for key, config in AI_COMPONENTS.items():
        if any(kw in requirement for kw in config['keywords']):
            detected.append(config)
    return detected
```

### 5.3 ChatBot模板

```tsx
// templates/AIChatBot.tsx
export function AIChatBot({ apiEndpoint }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const send = async () => {
    if (!input.trim()) return;
    
    setMessages(m => [...m, { role: 'user', content: input }]);
    setInput('');
    
    const res = await fetch(apiEndpoint, {
      method: 'POST',
      body: JSON.stringify({ message: input, history: messages })
    });
    const data = await res.json();
    
    setMessages(m => [...m, { role: 'assistant', content: data.response }]);
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white rounded-lg shadow-xl">
      <div className="h-80 overflow-y-auto p-4">
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'text-right' : ''}>
            <span className={`inline-block p-2 rounded ${
              m.role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-100'
            }`}>
              {m.content}
            </span>
          </div>
        ))}
      </div>
      <div className="border-t p-2 flex">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && send()}
          className="flex-1 border rounded px-2"
          placeholder="输入消息..."
        />
        <button onClick={send} className="ml-2 px-4 bg-blue-500 text-white rounded">
          发送
        </button>
      </div>
    </div>
  );
}
```

---

## 6. Stripe支付

### 6.1 使用方式
```
用户: "添加会员订阅，月付99，年付999"

AI生成:
├── Stripe配置
├── 定价页面UI
├── Checkout流程
├── Webhook处理
└── 订阅状态管理
```

### 6.2 定价页模板

```tsx
// templates/stripe/PricingPage.tsx
export function PricingPage({ plans }) {
  const subscribe = async (priceId) => {
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      body: JSON.stringify({ priceId })
    });
    const { sessionId } = await res.json();
    
    const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_KEY);
    stripe.redirectToCheckout({ sessionId });
  };

  return (
    <div className="flex justify-center gap-8 py-12">
      {plans.map(plan => (
        <div key={plan.id} className="border rounded-lg p-6 w-64">
          <h3 className="text-xl font-bold">{plan.name}</h3>
          <div className="text-3xl my-4">¥{plan.price}<span className="text-sm">/{plan.interval}</span></div>
          <ul className="mb-4">
            {plan.features.map(f => <li key={f}>✓ {f}</li>)}
          </ul>
          <button onClick={() => subscribe(plan.priceId)} className="w-full bg-blue-500 text-white py-2 rounded">
            订阅
          </button>
        </div>
      ))}
    </div>
  );
}
```

---

## 7. 代码导出

### 7.1 导出选项

```go
// POST /api/v1/projects/:id/export
type ExportRequest struct {
    Format     string `json:"format"` // zip / github
    IncludeEnv bool   `json:"include_env"`
}

type ExportResponse struct {
    DownloadURL string `json:"download_url,omitempty"`
    GitHubURL   string `json:"github_url,omitempty"`
}
```

### 7.2 无锁定承诺

导出代码包含：
- 标准技术栈 (Next.js/Node.js/Go)
- 完整 package.json / go.mod
- Dockerfile + docker-compose.yml
- README.md 部署说明
- .env.example 环境变量模板

---

## 8. 实时预览

### 8.1 架构

```
┌──────────────────────┐    ┌──────────────────────┐
│      对话区域        │    │       预览区域       │
│                      │    │    ┌──────────┐     │
│  用户: 改成蓝色      │    │    │  iframe  │     │
│  AI: 好的           │    │    │ (沙盒URL)│     │
│                      │    │    └──────────┘     │
│                      │    │  [桌面][平板][手机]  │
└──────────────────────┘    └──────────────────────┘
```

### 8.2 实现

```tsx
export function Preview({ projectId }) {
  const iframeRef = useRef();
  const [mode, setMode] = useState('desktop');
  
  // 监听代码变更，自动刷新
  useEffect(() => {
    const ws = new WebSocket(`ws://api/ws/projects/${projectId}`);
    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === 'code_updated') {
        iframeRef.current?.contentWindow?.location.reload();
      }
    };
    return () => ws.close();
  }, [projectId]);

  const sizes = {
    desktop: '100%',
    tablet: '768px',
    mobile: '375px'
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-center gap-2 p-2 border-b">
        {['desktop', 'tablet', 'mobile'].map(m => (
          <button key={m} onClick={() => setMode(m)}>{m}</button>
        ))}
      </div>
      <div className="flex-1 flex items-center justify-center bg-gray-100">
        <iframe
          ref={iframeRef}
          src={`/api/preview/${projectId}`}
          style={{ width: sizes[mode] }}
          className="h-full bg-white shadow"
        />
      </div>
    </div>
  );
}
```

---

## 9. WebSocket通信

### 9.1 消息类型

```go
const (
    // 服务端 -> 客户端
    MsgAIResponse   = "ai_response"
    MsgCodeUpdated  = "code_updated"
    MsgTaskProgress = "task_progress"
    MsgError        = "error"
    
    // 客户端 -> 服务端
    MsgUserMessage = "user_message"
    MsgStopTask    = "stop_task"
)

type WSMessage struct {
    Type    string      `json:"type"`
    Payload interface{} `json:"payload"`
}
```

### 9.2 服务端

```go
func ProjectWebSocket(c *gin.Context) {
    projectID := c.Param("id")
    conn, _ := upgrader.Upgrade(c.Writer, c.Request, nil)
    defer conn.Close()
    
    hub.Register(projectID, conn)
    defer hub.Unregister(projectID, conn)
    
    for {
        var msg WSMessage
        if err := conn.ReadJSON(&msg); err != nil {
            break
        }
        
        switch msg.Type {
        case MsgUserMessage:
            go handleUserMessage(projectID, msg.Payload, conn)
        case MsgStopTask:
            taskManager.Stop(projectID)
        }
    }
}
```
