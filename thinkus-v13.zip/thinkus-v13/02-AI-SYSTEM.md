# 02 AI系统

## 1. 概述

AI系统包含三个核心模块：
1. **AI员工引擎** - 模拟开发团队角色
2. **上下文管理** - 解决大项目"上下文腐败"问题
3. **自动验证** - 确保生成代码质量

```
用户需求 → AI员工理解 → 上下文准备 → Claude Code执行 → 自动验证 → 输出
```

---

## 2. AI员工引擎

### 2.1 角色定义

| ID | 角色 | 职责 | 触发场景 |
|----|------|------|----------|
| mike_pm | 产品经理 | 需求分析、任务分解、计划确认 | 新需求、计划讨论 |
| david_tech | 技术负责人 | 技术方案、架构决策 | 技术问题、架构设计 |
| elena_ux | UX设计师 | 界面设计、交互优化 | UI相关需求 |
| kevin_qa | QA工程师 | 测试验证、质量把控 | 代码完成后 |

### 2.2 实现

```python
# services/ai_employees/engine.py
from dataclasses import dataclass
from typing import List, Optional
import anthropic


@dataclass
class AIResponse:
    text: str
    actions: List['Action'] = None
    
@dataclass  
class Action:
    type: str  # "create_file", "modify_file", "approve_plan"
    params: dict


class AIEmployeeEngine:
    """AI员工引擎"""
    
    def __init__(self):
        self.client = anthropic.Anthropic()
        self.employees = {
            'mike_pm': MikePM(),
            'david_tech': DavidTech(),
            'elena_ux': ElenaUX(),
            'kevin_qa': KevinQA(),
        }
        self.conversation_history = {}  # project_id -> messages
    
    def chat(
        self,
        employee_id: str,
        message: str,
        project_id: str,
        context_files: List[str] = None
    ) -> AIResponse:
        """与AI员工对话"""
        employee = self.employees[employee_id]
        
        # 获取对话历史
        history = self.conversation_history.get(project_id, [])
        
        # 构建消息
        messages = history + [{"role": "user", "content": message}]
        
        # 调用Claude
        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=employee.system_prompt,
            messages=messages
        )
        
        # 解析响应
        result = self._parse_response(response.content[0].text)
        
        # 保存历史
        history.append({"role": "user", "content": message})
        history.append({"role": "assistant", "content": response.content[0].text})
        self.conversation_history[project_id] = history[-20:]  # 保留最近20条
        
        return result
    
    def _parse_response(self, text: str) -> AIResponse:
        """解析AI响应，提取actions"""
        actions = []
        
        # 简单的action提取逻辑
        if "```action" in text:
            # 解析action块...
            pass
        
        return AIResponse(text=text, actions=actions)


class MikePM:
    """产品经理Mike"""
    
    system_prompt = """你是Mike，Thinkus的产品经理。

你的职责：
1. 理解用户需求，提出澄清问题
2. 将需求分解为可执行的任务
3. 制定开发计划并与用户确认
4. 协调团队其他成员

你的风格：
- 友好专业，像真正的PM一样沟通
- 主动确认需求细节
- 给出明确的计划和时间估算

输出格式：
当需要执行操作时，使用action块：
```action
type: create_plan
params:
  tasks: [...]
  estimated_time: 30min
```"""


class DavidTech:
    """技术负责人David"""
    
    system_prompt = """你是David，Thinkus的技术负责人。

你的职责：
1. 制定技术方案
2. 做架构决策
3. 解决技术难题
4. 代码审查

你的风格：
- 技术专业，解释清晰
- 考虑可扩展性和维护性
- 给出具体的技术建议

技术栈偏好：
- 前端：Next.js, React, TailwindCSS
- 后端：Node.js/Python/Go
- 数据库：PostgreSQL, Redis
- 部署：Docker, Vercel"""


class KevinQA:
    """QA工程师Kevin"""
    
    system_prompt = """你是Kevin，Thinkus的QA工程师。

你的职责：
1. 评估代码质量
2. 设计测试用例
3. 发现潜在问题
4. 验证功能完整性

你的风格：
- 严谨细致
- 关注边界情况
- 给出具体的改进建议"""
```

### 2.3 路由决策

```python
# services/ai_employees/router.py

class EmployeeRouter:
    """决定哪个AI员工处理消息"""
    
    KEYWORDS = {
        'mike_pm': ['需求', '功能', '计划', '想做', '帮我做', '产品'],
        'david_tech': ['技术', '架构', '实现', '代码', 'bug', '报错', 'API'],
        'elena_ux': ['界面', 'UI', '设计', '样式', '布局', '颜色'],
        'kevin_qa': ['测试', '验证', '质量', '检查'],
    }
    
    def route(self, message: str, context: dict) -> str:
        """返回应该处理消息的员工ID"""
        
        # 1. 如果用户明确@某人
        if '@mike' in message.lower():
            return 'mike_pm'
        if '@david' in message.lower():
            return 'david_tech'
        # ...
        
        # 2. 根据关键词判断
        message_lower = message.lower()
        scores = {}
        for emp_id, keywords in self.KEYWORDS.items():
            scores[emp_id] = sum(1 for kw in keywords if kw in message_lower)
        
        if max(scores.values()) > 0:
            return max(scores, key=scores.get)
        
        # 3. 根据项目状态判断
        if context.get('phase') == 'planning':
            return 'mike_pm'
        if context.get('phase') == 'coding':
            return 'david_tech'
        if context.get('phase') == 'testing':
            return 'kevin_qa'
        
        # 4. 默认Mike
        return 'mike_pm'
```

---

## 3. 上下文管理

### 3.1 问题：上下文腐败

当项目变大时，AI会：
- 修改A模块时遗忘B模块的依赖
- 写出与全局架构冲突的代码
- 项目越大，AI越"降智"

### 3.2 解决方案

```
┌────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  大任务 ──→ TaskDecomposer ──→ 小任务列表 (每个<50K tokens)               │
│                                                                             │
│  小任务 ──→ CodeIndexer ──→ 找到相关文件                                  │
│                                                                             │
│  相关文件 ──→ PromptBuilder ──→ 精准Prompt                                │
│                                                                             │
│  精准Prompt ──→ Claude Code ──→ 高质量代码                                │
│                                                                             │
└────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 CodeIndexer - 代码索引器

```python
# services/context_manager/indexer.py
import os
import ast
import json
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class FileIndex:
    """文件索引"""
    path: str
    language: str
    line_count: int
    exports: List[str]      # 导出的函数/类
    imports: List[str]      # 导入的模块
    summary: str            # 文件摘要
    signatures: List[str]   # 函数签名


class CodeIndexer:
    """代码库索引器 - 不存全文，只存摘要"""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.index: Dict[str, FileIndex] = {}
    
    def build_index(self):
        """构建索引"""
        for file_path in self._scan_files():
            rel_path = str(file_path.relative_to(self.project_path))
            
            # 解析文件结构
            structure = self._parse_file(file_path)
            
            self.index[rel_path] = FileIndex(
                path=rel_path,
                language=self._detect_language(file_path),
                line_count=self._count_lines(file_path),
                exports=structure.get('exports', []),
                imports=structure.get('imports', []),
                summary=self._generate_summary(file_path, structure),
                signatures=structure.get('signatures', [])
            )
        
        # 保存索引
        self.save_index()
    
    def get_relevant_files(self, task: str, max_files: int = 8) -> List[str]:
        """根据任务找相关文件"""
        scores = {}
        task_lower = task.lower()
        
        for path, idx in self.index.items():
            score = 0
            
            # 文件名匹配
            for word in task_lower.split():
                if word in path.lower():
                    score += 0.3
            
            # 导出匹配
            for export in idx.exports:
                if export.lower() in task_lower:
                    score += 0.2
            
            # 摘要匹配
            for word in task_lower.split():
                if word in idx.summary.lower():
                    score += 0.1
            
            scores[path] = min(score, 1.0)
        
        # 按分数排序
        sorted_files = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [f[0] for f in sorted_files[:max_files]]
    
    def _parse_file(self, file_path: Path) -> dict:
        """解析文件结构"""
        suffix = file_path.suffix.lower()
        
        if suffix == '.py':
            return self._parse_python(file_path)
        elif suffix in ['.ts', '.tsx', '.js', '.jsx']:
            return self._parse_javascript(file_path)
        else:
            return {}
    
    def _parse_python(self, file_path: Path) -> dict:
        """解析Python文件"""
        try:
            with open(file_path, 'r') as f:
                tree = ast.parse(f.read())
            
            exports = []
            imports = []
            signatures = []
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                        
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append(node.module)
                        
                elif isinstance(node, ast.FunctionDef):
                    if not node.name.startswith('_'):
                        exports.append(node.name)
                        args = [a.arg for a in node.args.args]
                        signatures.append(f"def {node.name}({', '.join(args)})")
                        
                elif isinstance(node, ast.ClassDef):
                    if not node.name.startswith('_'):
                        exports.append(node.name)
                        signatures.append(f"class {node.name}")
            
            return {'exports': exports, 'imports': imports, 'signatures': signatures}
        except:
            return {}
    
    def _generate_summary(self, file_path: Path, structure: dict) -> str:
        """生成文件摘要"""
        exports = structure.get('exports', [])
        return f"Contains: {', '.join(exports[:5])}" if exports else "Utility file"
    
    def save_index(self):
        """保存索引到文件"""
        data = {
            path: {
                'path': idx.path,
                'language': idx.language,
                'line_count': idx.line_count,
                'exports': idx.exports,
                'summary': idx.summary,
                'signatures': idx.signatures
            }
            for path, idx in self.index.items()
        }
        
        index_path = self.project_path / '.thinkus' / 'index.json'
        index_path.parent.mkdir(exist_ok=True)
        
        with open(index_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_index(self):
        """从文件加载索引"""
        index_path = self.project_path / '.thinkus' / 'index.json'
        
        if index_path.exists():
            with open(index_path) as f:
                data = json.load(f)
            
            for path, info in data.items():
                self.index[path] = FileIndex(**info)
    
    def _scan_files(self):
        """扫描项目文件"""
        ignore = {'.git', 'node_modules', '__pycache__', '.thinkus', 'dist', 'build'}
        extensions = {'.py', '.js', '.ts', '.tsx', '.jsx', '.go', '.java', '.rb'}
        
        for root, dirs, files in os.walk(self.project_path):
            dirs[:] = [d for d in dirs if d not in ignore]
            
            for file in files:
                if Path(file).suffix.lower() in extensions:
                    yield Path(root) / file
```

### 3.4 PromptBuilder - Prompt构建器

```python
# services/context_manager/prompt_builder.py
from dataclasses import dataclass
from typing import List


@dataclass
class TaskPrompt:
    """发送给Claude Code的Prompt"""
    instruction: str
    context_files: List[str]
    context_snippet: str
    constraints: List[str]


class PromptBuilder:
    """构建精准的Prompt"""
    
    MAX_CONTEXT_TOKENS = 50000
    
    def __init__(self, indexer: 'CodeIndexer', project_path: str):
        self.indexer = indexer
        self.project_path = project_path
    
    def build(
        self,
        task_id: str,
        task_description: str,
        relevant_files: List[str]
    ) -> TaskPrompt:
        """构建任务Prompt"""
        
        # 1. 收集依赖文件
        all_files = set(relevant_files)
        for f in relevant_files[:3]:
            deps = self._get_dependencies(f)
            all_files.update(deps)
        
        # 2. 构建上下文片段
        context_snippet = self._build_context(list(all_files))
        
        # 3. 生成约束
        constraints = [
            "保持现有代码风格",
            "添加必要的错误处理",
            "不要删除现有功能",
        ]
        
        # 4. 构建主指令
        instruction = f"""## 任务
{task_description}

## 相关文件
{chr(10).join(f'- {f}' for f in relevant_files[:5])}

## 工作步骤
1. 先理解现有代码结构
2. 实现所需修改
3. 确保代码可以编译
4. 添加必要的注释

## 输出
只输出需要修改/创建的文件，使用完整内容。
"""
        
        return TaskPrompt(
            instruction=instruction,
            context_files=list(all_files),
            context_snippet=context_snippet,
            constraints=constraints
        )
    
    def _build_context(self, files: List[str]) -> str:
        """构建上下文片段"""
        snippets = []
        total_lines = 0
        max_lines = 500
        
        for file_path in files:
            if total_lines >= max_lines:
                break
            
            idx = self.indexer.index.get(file_path)
            if not idx:
                continue
            
            # 添加文件信息
            snippets.append(f"// === {file_path} ===")
            snippets.append(f"// {idx.summary}")
            
            if idx.signatures:
                snippets.append("// Signatures: " + ", ".join(idx.signatures[:5]))
            
            # 核心文件加载部分代码
            if total_lines < max_lines * 0.5:
                preview = self._get_file_preview(file_path, 30)
                snippets.append(preview)
                total_lines += 30
            
            snippets.append("")
        
        return '\n'.join(snippets)
    
    def _get_file_preview(self, file_path: str, max_lines: int) -> str:
        """获取文件预览"""
        full_path = f"{self.project_path}/{file_path}"
        try:
            with open(full_path) as f:
                lines = f.readlines()[:max_lines]
            return ''.join(lines)
        except:
            return f"// Could not read {file_path}"
    
    def _get_dependencies(self, file_path: str) -> List[str]:
        """获取文件依赖"""
        idx = self.indexer.index.get(file_path)
        if not idx:
            return []
        
        deps = []
        for imp in idx.imports:
            # 查找项目内的导入
            for path in self.indexer.index:
                if imp.replace('.', '/') in path:
                    deps.append(path)
                    break
        
        return deps[:3]  # 最多3个依赖
```

### 3.5 TaskDecomposer - 任务分解器

```python
# services/context_manager/task_decomposer.py
from dataclasses import dataclass
from typing import List


@dataclass
class SubTask:
    """子任务"""
    id: str
    title: str
    description: str
    difficulty: str  # easy, medium, hard
    target_files: List[str]
    dependencies: List[str]
    estimated_minutes: int


class TaskDecomposer:
    """将大任务分解为小任务"""
    
    MAX_TASK_CONTEXT = 50000  # 每个任务最大上下文tokens
    
    def __init__(self, indexer: 'CodeIndexer', ai_engine: 'AIEmployeeEngine'):
        self.indexer = indexer
        self.ai = ai_engine
    
    def decompose(self, requirement: str) -> List[SubTask]:
        """分解任务"""
        
        # 让Mike分析需求并分解任务
        response = self.ai.chat(
            employee_id='mike_pm',
            message=f"""请将以下需求分解为可独立执行的开发任务：

需求：{requirement}

要求：
1. 每个任务涉及的文件不超过5个
2. 任务之间的依赖关系要清晰
3. 先基础再核心

输出JSON：
[
  {{
    "id": "T1",
    "title": "任务标题",
    "description": "详细描述",
    "difficulty": "medium",
    "target_files": ["src/xxx.ts"],
    "dependencies": [],
    "estimated_minutes": 15
  }}
]""",
            project_id='system'
        )
        
        # 解析任务
        tasks = self._parse_tasks(response.text)
        
        # 验证每个任务的上下文大小
        validated_tasks = []
        for task in tasks:
            context_size = self._estimate_context_size(task)
            
            if context_size > self.MAX_TASK_CONTEXT:
                # 任务太大，继续拆分
                sub_tasks = self._split_task(task)
                validated_tasks.extend(sub_tasks)
            else:
                validated_tasks.append(task)
        
        return validated_tasks
    
    def _estimate_context_size(self, task: SubTask) -> int:
        """估算任务上下文大小"""
        size = 5000  # 基础Prompt大小
        
        for file_path in task.target_files:
            idx = self.indexer.index.get(file_path)
            if idx:
                size += idx.line_count * 10  # 1行约10 tokens
        
        return size
    
    def _split_task(self, task: SubTask) -> List[SubTask]:
        """拆分过大的任务"""
        files = task.target_files
        mid = len(files) // 2
        
        return [
            SubTask(
                id=f"{task.id}_1",
                title=f"{task.title} (Part 1)",
                description=task.description,
                difficulty=task.difficulty,
                target_files=files[:mid],
                dependencies=task.dependencies,
                estimated_minutes=task.estimated_minutes // 2
            ),
            SubTask(
                id=f"{task.id}_2",
                title=f"{task.title} (Part 2)",
                description=task.description,
                difficulty=task.difficulty,
                target_files=files[mid:],
                dependencies=[f"{task.id}_1"],
                estimated_minutes=task.estimated_minutes // 2
            )
        ]
    
    def _parse_tasks(self, text: str) -> List[SubTask]:
        """解析任务JSON"""
        import json
        import re
        
        match = re.search(r'\[.*\]', text, re.DOTALL)
        if not match:
            return []
        
        try:
            data = json.loads(match.group())
            return [SubTask(**t) for t in data]
        except:
            return []
```

---

## 4. 自动验证

### 4.1 验证流程

```
代码生成完成
     ↓
构建检查 (npm build / go build)
     ↓ 失败则返回
测试检查 (npm test / go test)
     ↓ 失败则返回
规范检查 (eslint / golint)
     ↓
通过 → 下一任务
```

### 4.2 实现

```python
# services/auto_verify/verifier.py
import subprocess
from dataclasses import dataclass
from typing import List, Optional
from pathlib import Path


@dataclass
class VerifyResult:
    """验证结果"""
    success: bool
    build_passed: bool
    tests_passed: bool
    lint_passed: bool
    issues: List[str]


class AutoVerifier:
    """自动验证器"""
    
    def verify(self, project_path: str, files: List[str] = None) -> VerifyResult:
        """验证项目"""
        issues = []
        
        # 检测项目类型
        project_type = self._detect_project_type(project_path)
        
        # 1. 构建检查
        build_passed, build_issues = self._check_build(project_path, project_type)
        issues.extend(build_issues)
        
        if not build_passed:
            return VerifyResult(
                success=False,
                build_passed=False,
                tests_passed=False,
                lint_passed=False,
                issues=issues
            )
        
        # 2. 测试检查
        tests_passed, test_issues = self._run_tests(project_path, project_type)
        issues.extend(test_issues)
        
        # 3. 规范检查
        lint_passed, lint_issues = self._check_lint(project_path, project_type, files)
        issues.extend(lint_issues)
        
        return VerifyResult(
            success=build_passed and tests_passed and lint_passed,
            build_passed=build_passed,
            tests_passed=tests_passed,
            lint_passed=lint_passed,
            issues=issues
        )
    
    def _detect_project_type(self, project_path: str) -> str:
        """检测项目类型"""
        path = Path(project_path)
        
        if (path / 'package.json').exists():
            return 'node'
        elif (path / 'go.mod').exists():
            return 'go'
        elif (path / 'requirements.txt').exists() or (path / 'pyproject.toml').exists():
            return 'python'
        else:
            return 'unknown'
    
    def _check_build(self, project_path: str, project_type: str) -> tuple:
        """构建检查"""
        commands = {
            'node': ['npm', 'run', 'build'],
            'go': ['go', 'build', './...'],
            'python': ['python', '-m', 'py_compile', '.'],
        }
        
        cmd = commands.get(project_type)
        if not cmd:
            return True, []
        
        try:
            result = subprocess.run(
                cmd,
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                return True, []
            else:
                return False, [f"Build failed: {result.stderr[:500]}"]
        except Exception as e:
            return False, [f"Build error: {str(e)}"]
    
    def _run_tests(self, project_path: str, project_type: str) -> tuple:
        """运行测试"""
        commands = {
            'node': ['npm', 'test', '--', '--passWithNoTests'],
            'go': ['go', 'test', './...'],
            'python': ['pytest', '-q'],
        }
        
        cmd = commands.get(project_type)
        if not cmd:
            return True, []
        
        try:
            result = subprocess.run(
                cmd,
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                return True, []
            else:
                return False, [f"Tests failed: {result.stderr[:500]}"]
        except Exception as e:
            return True, []  # 没有测试也算通过
    
    def _check_lint(self, project_path: str, project_type: str, files: List[str]) -> tuple:
        """代码规范检查"""
        if not files:
            return True, []
        
        issues = []
        
        if project_type == 'node':
            # ESLint检查
            try:
                result = subprocess.run(
                    ['npx', 'eslint', '--format', 'compact'] + files,
                    cwd=project_path,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                if result.returncode != 0:
                    issues.append(f"Lint issues: {result.stdout[:500]}")
            except:
                pass
        
        return len(issues) == 0, issues
```

---

## 5. 防摸鱼机制

防止AI挑简单任务，回避核心难题。

```python
# services/context_manager/anti_slacking.py
from enum import Enum
from dataclasses import dataclass
from typing import Dict, List


class TaskDifficulty(Enum):
    EASY = 1
    MEDIUM = 2
    HARD = 3
    CRITICAL = 4  # 必须完成


@dataclass
class Task:
    id: str
    title: str
    difficulty: TaskDifficulty
    is_core: bool  # 是否核心功能


class AntiSlackingManager:
    """防摸鱼管理器"""
    
    def __init__(self):
        self.completed_tasks: Dict[str, List[Task]] = {}  # worker -> tasks
    
    def get_next_task(self, worker_id: str, pending_tasks: List[Task]) -> Task:
        """获取下一个任务（防摸鱼逻辑）"""
        
        # 1. CRITICAL任务必须先做
        critical = [t for t in pending_tasks if t.difficulty == TaskDifficulty.CRITICAL]
        if critical:
            return critical[0]
        
        # 2. 检查worker是否在摸鱼
        if self._is_slacking(worker_id):
            # 强制分配困难任务
            hard = [t for t in pending_tasks if t.difficulty == TaskDifficulty.HARD]
            if hard:
                return hard[0]
        
        # 3. 核心任务优先
        core = [t for t in pending_tasks if t.is_core]
        if core:
            return max(core, key=lambda t: t.difficulty.value)
        
        # 4. 按难度排序
        return max(pending_tasks, key=lambda t: t.difficulty.value)
    
    def _is_slacking(self, worker_id: str) -> bool:
        """检查是否在摸鱼"""
        completed = self.completed_tasks.get(worker_id, [])
        
        if len(completed) < 3:
            return False
        
        # 统计难度分布
        recent = completed[-5:]
        easy_count = sum(1 for t in recent if t.difficulty == TaskDifficulty.EASY)
        
        # 如果最近80%都是简单任务，判定为摸鱼
        return easy_count / len(recent) > 0.8
    
    def record_completion(self, worker_id: str, task: Task):
        """记录任务完成"""
        if worker_id not in self.completed_tasks:
            self.completed_tasks[worker_id] = []
        self.completed_tasks[worker_id].append(task)
```

---

## 6. 完整工作流

```python
# services/workflow.py

async def execute_project(project_id: str, requirement: str):
    """执行项目开发"""
    
    project_path = f"/workspaces/{project_id}"
    
    # 1. 初始化
    indexer = CodeIndexer(project_path)
    indexer.build_index()
    
    ai = AIEmployeeEngine()
    decomposer = TaskDecomposer(indexer, ai)
    verifier = AutoVerifier()
    
    # 2. Mike理解需求，生成计划
    plan_response = ai.chat(
        'mike_pm',
        f"用户需求：{requirement}\n请分析并确认开发计划。",
        project_id
    )
    # (等待用户确认计划)
    
    # 3. 分解任务
    tasks = decomposer.decompose(requirement)
    
    # 4. 执行每个任务
    for task in tasks:
        # 4a. 找相关文件
        relevant_files = indexer.get_relevant_files(task.description)
        
        # 4b. 构建Prompt
        builder = PromptBuilder(indexer, project_path)
        prompt = builder.build(task.id, task.description, relevant_files)
        
        # 4c. 执行代码生成 (调用Claude Code)
        executor = CodeExecutor(project_path)
        result = await executor.execute(prompt)
        
        # 4d. 验证
        verify_result = verifier.verify(project_path, result.files_modified)
        
        if not verify_result.success:
            # 重试或回滚
            if verify_result.build_passed:
                # 小问题，重试
                continue
            else:
                # 严重问题，回滚到检查点
                break
        
        # 4e. 更新索引
        indexer.build_index()
    
    # 5. 完成
    return {"success": True, "project_path": project_path}
```
