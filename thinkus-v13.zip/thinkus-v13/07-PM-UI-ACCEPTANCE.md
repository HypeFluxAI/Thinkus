# 07 PM界面验收机制

> Mike作为用户代表，在沙盒容器中模拟真实用户操作，验收界面和体验

---

## 1. 问题分析

### Kevin测试 vs Mike验收

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Kevin (QA) 能测的:                    Mike (PM) 要验的:                    │
│  ────────────────────                  ────────────────────                  │
│                                                                              │
│  ✅ API返回正确数据                    ✅ 页面布局是否合理                  │
│  ✅ 数据库存储正确                     ✅ 按钮位置是否顺手                  │
│  ✅ 代码无语法错误                     ✅ 交互流程是否顺畅                  │
│  ✅ 构建能通过                         ✅ 加载状态是否友好                  │
│  ✅ 单元测试通过                       ✅ 错误提示是否清晰                  │
│                                        ✅ 整体"感觉"是否对                  │
│                                        ✅ 是否符合产品需求                  │
│                                                                              │
│  结论: Kevin测功能，Mike测体验                                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 为什么需要真实操作UI？

```
只看代码的问题:
├── 代码正确 ≠ 界面正确
├── API正确 ≠ 用户体验好
├── 测试通过 ≠ 产品达标
└── 无法感知真实用户视角

Mike需要:
├── 像真实用户一样打开页面
├── 点击按钮、填写表单
├── 感受加载速度、动画效果
├── 走完整个用户流程
└── 从产品角度判断是否达标
```

---

## 2. 解决方案：沙盒UI验收

### 2.1 整体架构

**技术选型: Browser Use (而非 Playwright)**

```
为什么用 Browser Use 而不是 Playwright？

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Playwright                          Browser Use                            │
│  ──────────                          ───────────                            │
│  • 需要写代码定位元素                 • AI自动理解页面                       │
│  • 依赖CSS选择器                      • 直接解析DOM，理解语义                │
│  • 脆弱，页面改动就失效               • 智能适应页面变化                     │
│  • 只能执行预定义操作                 • 可以执行自然语言指令                 │
│                                                                              │
│  结论: Browser Use 是 Manus 底层使用的框架，更适合AI驱动的UI验收           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

**架构图**

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                          沙盒UI验收架构                                      │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        沙盒容器 (Docker/E2B)                         │   │
│  │                                                                      │   │
│  │   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐            │   │
│  │   │   前端服务  │    │   后端服务  │    │   数据库    │            │   │
│  │   │  localhost  │←──→│  localhost  │←──→│  PostgreSQL │            │   │
│  │   │   :3000     │    │   :3001     │    │             │            │   │
│  │   └─────────────┘    └─────────────┘    └─────────────┘            │   │
│  │          ↑                                                          │   │
│  │          │ 浏览器访问                                               │   │
│  │          │                                                          │   │
│  │   ┌─────────────────────────────────────────────────────────────┐  │   │
│  │   │                    Browser Use Agent                         │  │   │
│  │   │                                                              │  │   │
│  │   │   Mike通过自然语言指令操作浏览器:                            │  │   │
│  │   │   • "打开登录页面"                                           │  │   │
│  │   │   • "填写邮箱test@test.com，密码123456"                      │  │   │
│  │   │   • "点击登录按钮"                                           │  │   │
│  │   │   • "检查是否显示欢迎信息"                                   │  │   │
│  │   │                                                              │  │   │
│  │   │   Browser Use自动:                                           │  │   │
│  │   │   • 解析DOM找到元素                                          │  │   │
│  │   │   • 执行操作                                                 │  │   │
│  │   │   • 截图返回                                                 │  │   │
│  │   │                                                              │  │   │
│  │   └─────────────────────────────────────────────────────────────┘  │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    │ DOM状态 + 截图                         │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                          Mike (PM)                                   │   │
│  │                                                                      │   │
│  │   基于DOM和截图判断:                                                │   │
│  │   • 界面是否符合需求                                                │   │
│  │   • 交互是否顺畅                                                    │   │
│  │   • 用户体验是否达标                                                │   │
│  │   • 提出修改建议                                                    │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 验收时机

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                         三层验收机制                                         │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Level 1: Kevin功能验收 (每个功能完成后)                             │   │
│  │  ────────────────────────────────────────                            │   │
│  │  • API测试                                                           │   │
│  │  • 单元测试                                                          │   │
│  │  • 代码规范检查                                                      │   │
│  │  → 确保代码正确                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Level 2: Mike UI验收 (每个功能完成后)                               │   │
│  │  ────────────────────────────────────                                │   │
│  │  • 打开页面截图                                                      │   │
│  │  • 操作交互截图                                                      │   │
│  │  • 对比需求判断                                                      │   │
│  │  → 确保界面符合产品需求                                              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  Level 3: Mike 流程验收 (每个迭代结束)                               │   │
│  │  ─────────────────────────────────────                               │   │
│  │  • 模拟完整用户流程                                                  │   │
│  │  • 注册→登录→浏览→购买                                              │   │
│  │  • 感受整体体验                                                      │   │
│  │  → 确保产品整体达标                                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. 实现方案

### 3.1 沙盒环境启动

```python
# services/sandbox/ui_sandbox.py

class UISandbox:
    """UI验收沙盒环境"""
    
    def __init__(self, project_id: str):
        self.project_id = project_id
        self.container = None
        self.browser = None
    
    async def start(self):
        """启动沙盒环境"""
        
        # 1. 启动Docker容器，包含完整运行环境
        self.container = await self._start_container()
        
        # 2. 在容器内启动服务
        await self._start_services()
        
        # 3. 启动Playwright浏览器
        self.browser = await self._start_browser()
        
        return self
    
    async def _start_container(self):
        """启动Docker容器"""
        
        # 使用预构建的沙盒镜像
        container = docker.run(
            image='thinkus/sandbox:latest',
            volumes={
                f'/workspaces/{self.project_id}': '/app'
            },
            ports={
                '3000': None,  # 前端
                '3001': None,  # 后端
            },
            detach=True
        )
        
        return container
    
    async def _start_services(self):
        """在容器内启动前后端服务"""
        
        # 安装依赖
        await self.container.exec('npm install')
        
        # 启动数据库
        await self.container.exec('docker-compose up -d db')
        
        # 运行migrations
        await self.container.exec('npx prisma migrate deploy')
        
        # 启动后端
        await self.container.exec('npm run start:backend &')
        
        # 启动前端
        await self.container.exec('npm run start:frontend &')
        
        # 等待服务就绪
        await self._wait_for_services()
    
    async def _start_browser(self):
        """启动Playwright浏览器"""
        
        from playwright.async_api import async_playwright
        
        playwright = await async_playwright().start()
        browser = await playwright.chromium.launch(
            headless=True,
            args=['--no-sandbox']
        )
        
        return browser
    
    async def get_page(self):
        """获取浏览器页面"""
        
        context = await self.browser.new_context(
            viewport={'width': 1280, 'height': 720}
        )
        page = await context.new_page()
        
        # 连接到容器内的前端服务
        frontend_url = self._get_frontend_url()
        await page.goto(frontend_url)
        
        return page
    
    async def stop(self):
        """停止沙盒环境"""
        
        if self.browser:
            await self.browser.close()
        if self.container:
            self.container.stop()
            self.container.remove()
```

### 3.2 Mike的UI操作能力 (基于Browser Use)

```python
# services/ai_employees/mike_ui_tester.py

from browser_use import Agent, Browser, Controller
from langchain_anthropic import ChatAnthropic

class MikeUITester:
    """Mike的UI验收能力 - 基于Browser Use"""
    
    def __init__(self, sandbox: UISandbox):
        self.sandbox = sandbox
        self.llm = ChatAnthropic(model="claude-sonnet-4-20250514")
        self.browser = None
        self.screenshots = []
    
    async def start_session(self):
        """开始验收会话"""
        # 启动Browser Use，连接到沙盒内的前端服务
        self.browser = Browser(
            headless=True,
            # 连接到沙盒容器
            browser_context_args={
                'base_url': self.sandbox.frontend_url
            }
        )
    
    # ==================== 自然语言操作 ====================
    
    async def execute_task(self, task_description: str) -> dict:
        """执行自然语言描述的任务"""
        
        agent = Agent(
            task=task_description,
            llm=self.llm,
            browser=self.browser,
            # 每一步都截图
            save_screenshots=True
        )
        
        result = await agent.run()
        
        # 收集截图
        for screenshot in result.screenshots:
            self.screenshots.append(screenshot)
        
        return {
            'success': result.success,
            'final_state': result.final_state,
            'screenshots': result.screenshots,
            'dom_content': result.dom_content
        }
    
    async def goto_and_analyze(self, path: str, requirement: str) -> dict:
        """访问页面并分析是否符合需求"""
        
        task = f"""
        1. 访问页面: {path}
        2. 等待页面加载完成
        3. 分析页面内容，判断是否符合以下需求:
           {requirement}
        4. 截图保存
        """
        
        result = await self.execute_task(task)
        
        # Mike分析截图
        analysis = await self._analyze_page(result, requirement)
        
        return analysis
    
    async def test_user_flow(self, flow_description: str) -> dict:
        """测试用户流程"""
        
        # Browser Use 可以直接执行复杂的多步骤任务
        result = await self.execute_task(flow_description)
        
        return result
    
    # ==================== 具体操作封装 ====================
    
    async def fill_form_and_submit(self, form_data: dict, submit_button: str) -> dict:
        """填写表单并提交"""
        
        # 构建自然语言任务
        fill_instructions = "\n".join([
            f"- 在{field}输入框中填写: {value}"
            for field, value in form_data.items()
        ])
        
        task = f"""
        {fill_instructions}
        然后点击"{submit_button}"按钮
        等待页面响应
        """
        
        return await self.execute_task(task)
    
    async def check_element_exists(self, element_description: str) -> bool:
        """检查元素是否存在"""
        
        task = f"检查页面上是否存在: {element_description}"
        result = await self.execute_task(task)
        
        return result['success']
    
    async def get_page_info(self) -> dict:
        """获取页面信息"""
        
        task = """
        分析当前页面，提取以下信息:
        1. 页面标题
        2. 所有标题文字 (h1, h2, h3)
        3. 所有按钮文字
        4. 所有表单字段
        5. 所有链接
        """
        
        result = await self.execute_task(task)
        
        return result
    
    # ==================== 分析能力 ====================
    
    async def _analyze_page(self, browser_result: dict, requirement: str) -> dict:
        """分析页面是否符合需求"""
        
        # 使用多模态能力分析截图
        screenshot_base64 = browser_result['screenshots'][-1] if browser_result['screenshots'] else None
        dom_content = browser_result.get('dom_content', '')
        
        prompt = f"""作为产品经理，分析这个页面是否符合需求。

需求: {requirement}

页面DOM结构摘要:
{dom_content[:2000]}

请评估:
1. 界面布局是否合理 (1-10分)
2. 必要元素是否完整 (列出缺失的)
3. 交互元素是否清晰 (按钮、链接、表单)
4. 整体是否符合需求

输出JSON:
{{
  "符合需求": true/false,
  "布局评分": 8,
  "完整性评分": 9,
  "缺失元素": [],
  "问题": [],
  "建议": []
}}"""
        
        if screenshot_base64:
            response = await self.ai.chat_with_vision('mike_pm', prompt, screenshot_base64)
        else:
            response = await self.ai.chat('mike_pm', prompt)
        
        return json.loads(response.text)
```

### 3.3 Mike的验收流程

```python
# services/ai_employees/mike_acceptance.py

from browser_use import Agent, Browser

class MikeAcceptance:
    """Mike的产品验收"""
    
    def __init__(self):
        self.ai = AIEngine()
        self.llm = ChatAnthropic(model="claude-sonnet-4-20250514")
    
    async def accept_feature(self, 
                            feature: Feature, 
                            contract: InterfaceContract,
                            sandbox: UISandbox) -> AcceptanceResult:
        """验收单个功能"""
        
        tester = MikeUITester(sandbox)
        await tester.start_session()
        
        # 1. 生成验收测试任务 (自然语言)
        test_tasks = await self._generate_test_tasks(feature, contract)
        
        # 2. 执行验收测试
        results = []
        for task in test_tasks:
            # Browser Use 直接执行自然语言任务
            result = await tester.execute_task(task.description)
            
            # 分析结果
            analysis = await self._analyze_result(task, result)
            results.append(analysis)
            
            if not analysis['passed']:
                break
        
        # 3. 综合评估
        evaluation = await self._evaluate_results(feature, results)
        
        return AcceptanceResult(
            feature_id=feature.id,
            success=evaluation.passed,
            score=evaluation.score,
            issues=evaluation.issues,
            suggestions=evaluation.suggestions,
            screenshots=tester.screenshots
        )
    
    async def _generate_test_tasks(self, feature: Feature, contract: InterfaceContract) -> List[TestTask]:
        """生成验收测试任务 (自然语言描述)"""
        
        prompt = f"""为以下功能生成UI验收测试任务：

功能: {feature.name}
描述: {feature.description}
页面: {contract.frontend.page}
表单字段: {contract.frontend.formFields}

请生成一系列自然语言测试任务，每个任务描述用户的完整操作流程。
例如:
- "打开登录页面，检查是否有邮箱和密码输入框，以及登录按钮"
- "填写邮箱test@test.com，密码123456，点击登录，检查是否跳转到首页"

输出JSON数组，每个任务包含:
- description: 任务的自然语言描述
- acceptance_criteria: 验收标准
"""
        
        response = await self.ai.chat('mike_pm', prompt)
        return self._parse_tasks(response.text)
    
    async def accept_iteration(self, 
                               iteration: Iteration, 
                               sandbox: UISandbox) -> IterationAcceptance:
        """验收整个迭代 - 完整用户旅程"""
        
        tester = MikeUITester(sandbox)
        await tester.start_session()
        
        # 1. 生成用户旅程
        journey = await self._generate_user_journey(iteration)
        
        # 2. 使用Browser Use执行完整用户旅程
        journey_result = await tester.test_user_flow(journey.description)
        
        # 3. 综合评估
        evaluation = await self._evaluate_journey(iteration, journey_result)
        
        return IterationAcceptance(
            iteration_id=iteration.id,
            success=evaluation.passed,
            score=evaluation.score,
            user_journey_result=journey_result,
            issues=evaluation.issues,
            suggestions=evaluation.suggestions
        )
    
    async def _generate_user_journey(self, iteration: Iteration) -> UserJourney:
        """生成用户旅程 (自然语言描述)"""
        
        prompt = f"""为以下迭代生成用户旅程测试：

迭代: {iteration.name}
目标: {iteration.goal}
包含功能: {[f.name for f in iteration.features]}

请设计一个完整的用户旅程，用自然语言描述真实用户会怎么使用这些功能。

例如对于电商网站:
"
1. 打开首页，浏览商品列表
2. 点击第一个商品，查看详情
3. 点击'加入购物车'按钮
4. 打开购物车页面，确认商品已添加
5. 点击'去结算'
6. 填写收货地址
7. 选择支付方式
8. 确认下单
9. 查看订单列表，确认订单已创建
"

输出完整的用户旅程描述。"""
        
        response = await self.ai.chat('mike_pm', prompt)
        return UserJourney(description=response.text)
```

### 3.4 完整验收流程集成

```python
# services/workflow/acceptance_workflow.py

class AcceptanceWorkflow:
    """验收工作流"""
    
    def __init__(self):
        self.kevin = KevinTester()
        self.mike = MikeAcceptance()
    
    async def accept_feature(self, 
                            project_id: str, 
                            feature: Feature,
                            contract: InterfaceContract) -> FeatureAcceptanceResult:
        """功能验收：Kevin + Mike"""
        
        # 1. Kevin功能测试
        kevin_result = await self.kevin.test_feature(project_id, feature, contract)
        
        if not kevin_result.success:
            return FeatureAcceptanceResult(
                success=False,
                stage='kevin_test',
                issues=kevin_result.issues
            )
        
        # 2. Mike UI验收 (在沙盒中)
        async with UISandbox(project_id) as sandbox:
            mike_result = await self.mike.accept_feature(feature, contract, sandbox)
        
        if not mike_result.success:
            return FeatureAcceptanceResult(
                success=False,
                stage='mike_acceptance',
                issues=mike_result.issues,
                suggestions=mike_result.suggestions,
                screenshots=mike_result.screenshots
            )
        
        return FeatureAcceptanceResult(
            success=True,
            kevin_result=kevin_result,
            mike_result=mike_result
        )
    
    async def accept_iteration(self, 
                               project_id: str, 
                               iteration: Iteration) -> IterationAcceptanceResult:
        """迭代验收"""
        
        # 1. Kevin集成测试
        kevin_result = await self.kevin.integration_test(project_id, iteration)
        
        if not kevin_result.success:
            return IterationAcceptanceResult(
                success=False,
                stage='kevin_integration',
                issues=kevin_result.issues
            )
        
        # 2. Mike用户旅程验收
        async with UISandbox(project_id) as sandbox:
            mike_result = await self.mike.accept_iteration(iteration, sandbox)
        
        if not mike_result.success:
            return IterationAcceptanceResult(
                success=False,
                stage='mike_journey',
                issues=mike_result.issues,
                suggestions=mike_result.suggestions
            )
        
        return IterationAcceptanceResult(
            success=True,
            kevin_result=kevin_result,
            mike_result=mike_result
        )
```

---

## 4. 验收标准

### 4.1 Mike的验收清单

```python
# Mike验收时会检查的内容

UI_ACCEPTANCE_CHECKLIST = {
    '布局': [
        '页面结构是否清晰',
        '重要内容是否突出',
        '留白是否合理',
        '对齐是否整齐',
    ],
    '交互': [
        '按钮是否可点击且明显',
        '表单是否易于填写',
        '加载状态是否有提示',
        '操作反馈是否及时',
    ],
    '体验': [
        '流程是否顺畅',
        '是否有迷惑的地方',
        '错误提示是否友好',
        '是否符合用户预期',
    ],
    '完整性': [
        '所有需求功能是否都有',
        '边界情况是否考虑',
        '必要的说明是否存在',
    ],
}
```

### 4.2 评分标准

```
10分: 完美，超出预期
9分:  优秀，几乎没有问题
8分:  良好，小问题不影响使用
7分:  合格，能用但有明显可改进处
6分:  勉强，需要修复才能上线
5分以下: 不合格，需要重做
```

---

## 5. 问题修复流程

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                      Mike验收发现问题后的处理                               │
│                                                                              │
│  Mike验收结果:                                                               │
│  ├── 评分: 6分                                                               │
│  ├── 问题:                                                                   │
│  │   1. 登录按钮太小，不易点击                                              │
│  │   2. 加载时没有提示，用户会困惑                                          │
│  │   3. 错误信息不够友好                                                    │
│  └── 建议:                                                                   │
│      1. 按钮高度增加到44px                                                  │
│      2. 添加loading状态                                                     │
│      3. 错误信息改为用户友好的提示                                          │
│                                                                              │
│                                    │                                        │
│                                    ▼                                        │
│                                                                              │
│  Mike分配修复任务:                                                           │
│  ├── 问题1 → Elena: 修改按钮样式                                            │
│  ├── 问题2 → Elena: 添加加载状态组件                                        │
│  └── 问题3 → Elena: 优化错误提示文案                                        │
│                                                                              │
│                                    │                                        │
│                                    ▼                                        │
│                                                                              │
│  Elena修复 → Kevin验证代码 → Mike再次UI验收                                 │
│                                                                              │
│  Mike再次验收:                                                               │
│  ├── 评分: 8分 ✓                                                            │
│  └── 通过验收                                                               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. 用户视角

```
Mike: "功能开发完成，Kevin测试通过。现在我来验收界面..."

[Mike在沙盒中启动应用]

Mike: "打开登录页面..."
[截图分析]

Mike: "我发现几个问题：

1. ⚠️ 登录按钮太小 (32px)，移动端不好点
   建议：增大到44px以上

2. ⚠️ 点击登录后没有加载提示
   建议：添加loading状态

3. ⚠️ 密码错误时显示'Error 401'
   建议：改为'密码不正确，请重试'

当前评分：6分，需要修复后才能通过。

Elena，请修复以上问题。"

[Elena修复]

Mike: "再次验收..."
[重新截图分析]

Mike: "✅ 按钮大小合适了
       ✅ 有加载提示了
       ✅ 错误信息友好了
       
       评分：8分，验收通过！"
```

---

## 7. 技术要点

### 7.1 Browser Use vs Playwright 对比

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                     Browser Use vs Playwright                               │
│                                                                              │
│  ┌─────────────────────────────┐    ┌─────────────────────────────┐        │
│  │        Playwright           │    │       Browser Use           │        │
│  ├─────────────────────────────┤    ├─────────────────────────────┤        │
│  │                             │    │                             │        │
│  │  await page.click(          │    │  agent = Agent(             │        │
│  │    'button.submit'          │    │    task="点击登录按钮",     │        │
│  │  )                          │    │    llm=llm                  │        │
│  │                             │    │  )                          │        │
│  │  问题:                      │    │  await agent.run()          │        │
│  │  • 需要知道CSS选择器        │    │                             │        │
│  │  • 页面改动就失效           │    │  优点:                      │        │
│  │  • 无法处理动态内容         │    │  • AI自动找到元素           │        │
│  │                             │    │  • 理解语义，适应变化       │        │
│  │                             │    │  • 可以处理复杂场景         │        │
│  └─────────────────────────────┘    └─────────────────────────────┘        │
│                                                                              │
│  场景: "检查页面上是否有登录表单"                                           │
│                                                                              │
│  Playwright:                                                                 │
│  forms = await page.query_selector_all('form')                              │
│  login_inputs = await page.query_selector_all('input[type="password"]')     │
│  # 需要手动判断...                                                          │
│                                                                              │
│  Browser Use:                                                                │
│  result = await agent.run(task="检查页面上是否有登录表单，包含用户名密码")  │
│  # AI自动分析并返回结论                                                     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 7.2 沙盒环境 (E2B 或 Docker)

```python
# 方案1: 使用E2B (推荐，Manus使用的方案)
from e2b_code_interpreter import Sandbox

class UISandbox:
    async def start(self):
        self.sandbox = Sandbox(template="thinkus-ui-sandbox")
        
        # 启动前后端服务
        self.sandbox.commands.run("npm install && npm run dev &")
        
        # 获取URL
        self.frontend_url = f"https://{self.sandbox.get_host(3000)}"

# 方案2: 使用Docker (自建)
class DockerUISandbox:
    async def start(self):
        self.container = docker.run(
            image='thinkus/sandbox:latest',
            volumes={f'/workspaces/{self.project_id}': '/app'},
            ports={'3000': None, '3001': None}
        )
```

### 7.3 Browser Use 代码示例

```python
from browser_use import Agent, Browser, Controller
from langchain_anthropic import ChatAnthropic

# 初始化
llm = ChatAnthropic(model="claude-sonnet-4-20250514")
browser = Browser(headless=True)

# 简单任务
agent = Agent(
    task="打开 http://localhost:3000/login，填写邮箱test@test.com和密码123456，然后点击登录",
    llm=llm,
    browser=browser
)
result = await agent.run()

# 复杂用户旅程
agent = Agent(
    task="""
    作为一个新用户，完成以下流程:
    1. 打开首页
    2. 点击注册
    3. 填写注册表单 (随机生成邮箱和密码)
    4. 提交注册
    5. 自动登录后，浏览商品列表
    6. 点击第一个商品
    7. 加入购物车
    8. 查看购物车确认添加成功
    
    每一步都截图，最后告诉我整个流程是否顺畅。
    """,
    llm=llm,
    browser=browser,
    save_screenshots=True
)
result = await agent.run()

print(f"流程完成: {result.success}")
print(f"截图数量: {len(result.screenshots)}")
print(f"最终结论: {result.final_message}")
```

### 7.4 Mike验收示例

```python
# Mike验收登录功能
async def mike_accept_login(sandbox: UISandbox):
    tester = MikeUITester(sandbox)
    await tester.start_session()
    
    # 1. 检查登录页面
    result1 = await tester.execute_task("""
    打开登录页面，检查:
    1. 是否有邮箱输入框
    2. 是否有密码输入框
    3. 是否有登录按钮
    4. 整体布局是否合理
    """)
    
    # 2. 测试登录流程
    result2 = await tester.execute_task("""
    1. 填写邮箱: test@test.com
    2. 填写密码: password123
    3. 点击登录按钮
    4. 检查是否成功跳转到首页
    5. 检查是否显示用户信息
    """)
    
    # 3. 测试错误处理
    result3 = await tester.execute_task("""
    1. 打开登录页面
    2. 填写错误的密码
    3. 点击登录
    4. 检查是否显示友好的错误提示 (不是Error 401)
    """)
    
    # 4. Mike综合评估
    evaluation = await mike_evaluate([result1, result2, result3])
    
    return evaluation
```
```

---

## 8. 总结

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  双重验收机制                                                               │
│  ════════════                                                               │
│                                                                              │
│  Kevin (QA)                           Mike (PM)                             │
│  ─────────                            ─────────                             │
│  测功能正确性                         测用户体验                            │
│  API/代码/测试                        界面/交互/感觉                        │
│  自动化测试                           模拟真实用户操作                      │
│  在代码层面验证                       在UI层面验证                          │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  为什么需要Mike在沙盒中操作UI？                                             │
│  ─────────────────────────────                                              │
│  • 代码正确 ≠ 界面正确                                                      │
│  • 只有真正"看到"和"操作"才能感知体验                                       │
│  • 产品经理的"感觉"需要通过真实交互获得                                     │
│  • 发现Kevin无法发现的问题（按钮太小、加载无提示...）                       │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  验收时机                                                                   │
│  ────────                                                                   │
│  1. 每个功能完成 → Kevin测试 + Mike UI验收                                  │
│  2. 每个迭代结束 → Kevin集成测试 + Mike用户旅程验收                         │
│  3. 最终交付前 → 全面验收                                                   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```
