# Thinkus 多模型智能调度方案 (修正版)

> **核心原则**: 代码开发只能用 Claude Code 和 Codex，其他模型用于分析、规划、测试等非代码任务

---

## 一、模型价格对比 (2025-2026最新)

### 1.1 代码开发模型 (只能用这两个写代码)

| 模型 | 价格 | 上下文 | 特点 |
|------|------|--------|------|
| **Claude Code** | $20/月(Pro) $100/月(Max5x) $200/月(Max20x) | 200K | 理解整个代码库，多文件编辑，自动测试 |
| **OpenAI Codex** | $20/月(Plus) $200/月(Pro) 或 API $1.25/$10 | 400K | Agentic编程，CLI集成，GitHub集成 |

### 1.2 分析/规划模型 (不写代码，用于思考和分析)

| 模型 | Input ($/1M) | Output ($/1M) | 上下文 | 特点 |
|------|-------------|---------------|--------|------|
| **Gemini 3 Pro** | $2 | $12 | 1M | 最新最强，思考能力强，多模态 |
| **Gemini 3 Flash** | $0.50 | $3 | 1M | 快速便宜，有思考能力 |
| **Gemini 2.5 Pro** | $1.25 | $10 | 1M | 成熟稳定，长上下文 |
| **Gemini 2.5 Flash** | $0.15 | $0.60 | 1M | 极致便宜，高吞吐 |
| **Claude Opus 4.5** | $5 | $25 | 200K | 推理最强 |
| **Claude Sonnet 4.5** | $3 | $15 | 200K/1M | 平衡性价比 |
| **Claude Haiku 4.5** | $1 | $5 | 200K | 快速分类 |

---

## 二、各模型优缺点分析

### 2.1 代码开发模型

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Claude Code (代码开发首选)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • 终端原生，理解整个代码库                                                  │
│   • 多文件同时编辑，自动运行测试                                              │
│   • 代码质量极高，一次搞定复杂任务                                            │
│   • 订阅制成本可控 ($20-200/月)                                              │
│   • 支持 Sonnet 4.5 和 Opus 4.5                                              │
│                                                                              │
│ ❌ 缺点:                                                                     │
│   • 用量限制 (5小时滚动窗口 + 周限制)                                        │
│   • Pro用户周限40-80小时，Max20x为240-480小时                                │
│   • 重度使用可能撞限额                                                       │
│   • 只支持Claude模型                                                         │
│                                                                              │
│ 💰 订阅方案:                                                                 │
│   • Pro $20/月: 适合轻度开发，~45消息/5小时                                  │
│   • Max 5x $100/月: 中度开发，5倍Pro用量                                     │
│   • Max 20x $200/月: 重度开发，20倍Pro用量                                   │
│                                                                              │
│ 🎯 适用: 功能开发、代码重构、Bug修复、测试编写                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                        OpenAI Codex (代码开发备选)                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • Agentic任务优化，自主执行能力强                                          │
│   • 400K超大上下文                                                           │
│   • Codex Web (云端) + Codex CLI (本地) 双模式                               │
│   • GitHub深度集成，自动PR/Review                                            │
│   • GPT-5.2 最新模型支持                                                     │
│                                                                              │
│ ❌ 缺点:                                                                     │
│   • 订阅用量也有限制 (30-150消息/5小时 Plus)                                 │
│   • 代码质量略逊于Claude Code                                                │
│   • API使用成本不低                                                          │
│                                                                              │
│ 💰 订阅方案:                                                                 │
│   • Plus $20/月: 30-150消息/5小时                                            │
│   • Pro $200/月: 300-1500消息/5小时                                          │
│   • API: codex-mini $1.50/$6, GPT-5-Codex $1.25/$10                          │
│                                                                              │
│ 🎯 适用: GitHub集成任务、需要超长上下文、Claude限额后的备选                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 分析/规划模型 (不写代码)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Gemini 3 Pro (分析规划首选)                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • 2025年11月发布，最新最强                                                 │
│   • 原生思考能力 (thinking_level参数)                                        │
│   • 1M超长上下文，整个代码库一次分析                                         │
│   • 多模态强 (图片/音频/视频/代码)                                           │
│   • Google Search Grounding 实时信息                                         │
│   • 价格适中 ($2/$12)                                                        │
│                                                                              │
│ ❌ 缺点:                                                                     │
│   • 目前Preview阶段，稳定版预计Q1 2026                                       │
│   • 思考token计入输出费用                                                    │
│   • 超200K上下文价格翻倍 ($4/$18)                                            │
│                                                                              │
│ 🎯 适用: 需求分析、架构规划、技术调研、设计稿理解、代码库分析                │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                        Gemini 3 Flash (快速分析)                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • Pro级智能，Flash级速度和价格                                             │
│   • 有免费层                                                                 │
│   • $0.50/$3 极具性价比                                                      │
│   • 1M上下文                                                                 │
│                                                                              │
│ 🎯 适用: 日常分析、快速判断、批量处理                                        │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                        Claude Opus 4.5 (复杂推理)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • 推理能力业界最强                                                         │
│   • 复杂问题一次搞定                                                         │
│   • 指令遵循精准                                                             │
│                                                                              │
│ ❌ 缺点:                                                                     │
│   • 最贵 ($5/$25)                                                            │
│   • 200K上下文限制                                                           │
│                                                                              │
│ 🎯 适用: 架构决策、复杂问题分析、重要规划 (不写代码!)                        │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                        Claude Haiku 4.5 (快速分类)                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ✅ 优点:                                                                     │
│   • 极快 (毫秒级)                                                            │
│   • 极便宜 ($1/$5)                                                           │
│                                                                              │
│ 🎯 适用: 任务分类、路由决策、意图识别、简单问答                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 三、Thinkus各环节模型配置

### 3.1 总体架构

```
                              ┌─────────────────┐
                              │   用户请求      │
                              └────────┬────────┘
                                       │
                              ┌────────▼────────┐
                              │  Haiku 分类器   │ (快速判断任务类型)
                              └────────┬────────┘
                                       │
           ┌───────────────────────────┼───────────────────────────┐
           │                           │                           │
    ┌──────▼──────┐           ┌────────▼────────┐         ┌───────▼───────┐
    │  分析/规划   │           │    代码开发     │         │   快速任务    │
    │  Gemini 3   │           │  Claude Code    │         │    Haiku      │
    │  /Opus      │           │  /Codex         │         │    /Flash     │
    └─────────────┘           └─────────────────┘         └───────────────┘
```

### 3.2 详细配置表

```yaml
# ═══════════════════════════════════════════════════════════════
# 阶段1: 需求分析 (Mike PM) - 不写代码
# ═══════════════════════════════════════════════════════════════

需求理解和分析:
  主模型: Gemini 3 Pro
  成本: $2/$12
  原因: 
    - 需要理解用户意图，分析复杂需求
    - 1M上下文可以分析完整项目背景
    - 多模态可以理解用户上传的截图/文档
  
需求澄清对话:
  模型: Gemini 3 Flash
  成本: $0.50/$3
  原因: 简单问答不需要最强模型

市场调研:
  模型: Gemini 3 Pro + Google Search Grounding
  成本: $2/$12 + $35/1000次搜索
  原因: 实时获取市场信息

# ═══════════════════════════════════════════════════════════════
# 阶段2: 设计确认 (Elena UX) - 不写代码
# ═══════════════════════════════════════════════════════════════

设计稿理解:
  主模型: Gemini 3 Pro
  成本: $2/$12
  原因: 
    - 多模态强，理解Figma导出图片
    - 分析设计系统和组件

设计方案规划:
  模型: Gemini 3 Pro
  成本: $2/$12

设计稿对比:
  模型: Gemini 3 Pro
  成本: $2/$12
  原因: 图片对比能力强

# ═══════════════════════════════════════════════════════════════
# 阶段3: 架构规划 (David Tech) - 不写代码
# ═══════════════════════════════════════════════════════════════

架构设计:
  主模型: Claude Opus 4.5
  成本: $5/$25
  原因:
    - 架构决策影响全局，需要最强推理
    - 一次性把架构定好，避免返工
    - 复杂权衡需要深度思考

技术调研 (Librarian):
  主模型: Gemini 3 Pro + Google Search
  成本: $2/$12 + 搜索费用
  原因:
    - 1M上下文可以阅读完整技术文档
    - 实时获取最新技术信息

代码库分析:
  主模型: Gemini 3 Pro
  成本: $2/$12
  原因: 1M上下文一次性分析整个项目

数据库Schema设计:
  模型: Gemini 3 Pro
  成本: $2/$12
  原因: Schema规划不需要写代码

接口契约规划:
  模型: Gemini 3 Pro
  成本: $2/$12
  原因: API设计规划

# ═══════════════════════════════════════════════════════════════
# 阶段4: 代码开发 (核心) - 只能用Claude Code或Codex
# ═══════════════════════════════════════════════════════════════

前端代码开发:
  主模型: Claude Code (Max 5x订阅)
  备选: OpenAI Codex
  成本: $100/月订阅制
  原因:
    - React/Vue/Next.js代码质量高
    - 理解整个前端项目结构
    - 多文件同时修改

后端代码开发:
  主模型: Claude Code (Max 5x订阅)
  备选: OpenAI Codex
  成本: $100/月订阅制
  原因:
    - API实现稳定
    - 错误处理完善
    - 自动运行测试验证

复杂业务逻辑:
  主模型: Claude Code (使用Opus模式)
  成本: 订阅内
  原因: 复杂逻辑需要最强代码能力

大型重构:
  主模型: Claude Code
  成本: 订阅内
  原因:
    - 理解整个代码库
    - 多文件同时修改
    - 自动运行测试验证

测试代码编写:
  主模型: Claude Code
  备选: OpenAI Codex
  成本: 订阅内
  原因: 测试代码也是代码

数据库Migration:
  主模型: Claude Code
  成本: 订阅内

# ═══════════════════════════════════════════════════════════════
# 阶段5: 测试验证 (Kevin QA) - 分析用Gemini，修代码用Claude Code
# ═══════════════════════════════════════════════════════════════

测试结果分析:
  主模型: Gemini 3 Flash
  成本: $0.50/$3
  原因:
    - 分析大量测试日志
    - 不需要最强推理
    - 高吞吐低成本

疑难Bug分析:
  主模型: Claude Opus 4.5 (分析) → Claude Code (修复)
  成本: $5/$25 分析 + 订阅内修复
  原因:
    - Opus分析根因
    - Claude Code实施修复

Bug修复代码:
  主模型: Claude Code
  成本: 订阅内
  原因: 写代码只能用Claude Code

# ═══════════════════════════════════════════════════════════════
# 阶段6: UI验收 (Mike + Browser Use) - 验收分析
# ═══════════════════════════════════════════════════════════════

UI验收分析:
  主模型: Claude Sonnet 4.5 (Browser Use基于Claude)
  成本: API $3/$15
  原因:
    - Browser Use需要Claude
    - 分析截图判断UI质量

验收问题修复:
  主模型: Claude Code
  成本: 订阅内
  原因: 修复代码只能用Claude Code

# ═══════════════════════════════════════════════════════════════
# 辅助功能
# ═══════════════════════════════════════════════════════════════

任务分类/路由:
  主模型: Claude Haiku 4.5
  成本: $1/$5
  原因: 快速判断，成本极低

意图识别:
  主模型: Claude Haiku 4.5
  成本: $1/$5

简单问答:
  主模型: Gemini 3 Flash
  成本: $0.50/$3

批量日志分析:
  主模型: Gemini 2.5 Flash
  成本: $0.15/$0.60
  原因: 极致便宜

决策分级判断:
  L0/L1: Claude Haiku 4.5
  L2: Gemini 3 Pro  
  L3: Claude Opus 4.5
```

---

## 四、Claude Code + Codex 使用策略

### 4.1 Claude Code 最优使用

```python
# Claude Code 订阅选择
subscription_strategy = {
    '轻度开发': {
        'plan': 'Pro $20/月',
        'usage': '~45消息/5小时，周40-80小时',
        'suitable': '1-2个小项目，兼职开发'
    },
    '中度开发': {
        'plan': 'Max 5x $100/月',
        'usage': '5倍Pro，周140-280小时',
        'suitable': '3-5个项目，日常开发'
    },
    '重度开发': {
        'plan': 'Max 20x $200/月',
        'usage': '20倍Pro，周240-480小时',
        'suitable': '多项目并行，全职AI开发'
    }
}

# Thinkus推荐: Max 5x ($100/月) 作为基础
# 如果用量不够，升级到 Max 20x ($200/月)
```

### 4.2 Claude Code + Codex 互补策略

```python
class CodeDevRouter:
    """代码开发路由器"""
    
    def __init__(self):
        self.claude_code_available = True
        self.codex_available = True
    
    async def develop(self, task: CodeTask) -> str:
        # 策略1: 优先Claude Code
        if self.claude_code_available and not self.is_rate_limited('claude'):
            return await self.claude_code.execute(task)
        
        # 策略2: Claude Code限额后切Codex
        if self.codex_available:
            return await self.codex.execute(task)
        
        # 策略3: 等待限额恢复
        return await self.wait_and_retry(task)
    
    def is_rate_limited(self, provider: str) -> bool:
        """检查是否达到限额"""
        if provider == 'claude':
            # 检查5小时窗口和周限制
            return self.check_claude_limits()
        return False

# 具体场景
routing_rules = {
    # Claude Code 优先场景
    'complex_refactor': 'claude_code',      # 复杂重构
    'multi_file_edit': 'claude_code',       # 多文件编辑
    'test_driven_dev': 'claude_code',       # TDD开发
    'bug_fix': 'claude_code',               # Bug修复
    
    # Codex 适合场景
    'github_integration': 'codex',          # GitHub集成
    'long_context_code': 'codex',           # 超长上下文(400K)
    'ci_cd_tasks': 'codex',                 # CI/CD任务
    
    # 限额后降级
    'claude_limited': 'codex',              # Claude限额后
    'codex_limited': 'wait_or_api'          # 都限额了等待
}
```

### 4.3 API作为补充

```python
# 当订阅限额用完，可以用API继续
# Claude API: Sonnet $3/$15, Opus $5/$25
# Codex API: codex-mini $1.50/$6, GPT-5-Codex $1.25/$10

async def emergency_code_gen(task: CodeTask) -> str:
    """紧急情况用API"""
    if task.complexity == 'high':
        # 用Claude Sonnet API
        return await claude_api.generate(
            model='claude-sonnet-4-5',
            messages=[...],
            max_tokens=4096
        )
    else:
        # 用Codex-mini API (更便宜)
        return await openai_api.generate(
            model='codex-mini-latest',
            messages=[...]
        )
```

---

## 五、成本优化策略

### 5.1 订阅 vs API 成本对比

```yaml
# 假设每天开发4小时，每月20个工作日

Claude Code 订阅:
  Pro $20/月:
    - 周40-80小时，可能不够
    - 单价: $20 ÷ 80小时 = $0.25/小时
  
  Max 5x $100/月:
    - 周140-280小时，足够日常
    - 单价: $100 ÷ 280小时 = $0.36/小时
  
  Max 20x $200/月:
    - 周240-480小时，重度开发
    - 单价: $200 ÷ 480小时 = $0.42/小时

API (按量):
  Claude Sonnet: $3/$15 per 1M tokens
    - 假设每次调用平均5K tokens
    - 每调用成本: ~$0.08
    - 每小时50次: ~$4/小时
  
结论: 
  - 日常开发订阅更划算
  - API适合偶尔超额或特殊需求
```

### 5.2 Gemini省钱技巧

```python
# 1. 使用Prompt Caching (省50%)
# Gemini支持Context Caching，重复的System Prompt可缓存

# 2. 使用Batch API (省50%)
# 非紧急分析任务批量处理

# 3. 选择合适的模型
model_selection = {
    '简单分析': 'gemini-3-flash',      # $0.50/$3
    '日常分析': 'gemini-2.5-pro',       # $1.25/$10
    '复杂分析': 'gemini-3-pro',         # $2/$12
    '批量处理': 'gemini-2.5-flash',     # $0.15/$0.60
}

# 4. 上下文压缩
# 超长内容先用Flash压缩，再用Pro分析
async def analyze_large_context(content: str):
    if count_tokens(content) > 100000:
        # 先用便宜模型压缩
        summary = await gemini_flash.summarize(content)
        # 再用强模型分析
        return await gemini_3_pro.analyze(summary)
    return await gemini_3_pro.analyze(content)
```

---

## 六、完整成本估算

### 6.1 单项目成本

```yaml
假设: 一个中等复杂度Web应用 (20个功能点)

分析规划阶段 (Gemini):
  - 需求分析: 10轮 × Gemini 3 Pro = ~$1.00
  - 设计规划: 5轮 × Gemini 3 Pro = ~$0.50
  - 架构设计: 3轮 × Opus = ~$1.50
  - 技术调研: 5轮 × Gemini 3 Pro = ~$0.50
  - 代码库分析: 2轮 × Gemini 3 Pro = ~$0.30
  小计: ~$3.80

代码开发阶段 (Claude Code 订阅):
  - 20个功能开发
  - 每功能约2小时 = 40小时
  - Max 5x ($100/月) 可覆盖
  分摊到单项目: ~$30-50 (假设月做2-3个项目)

测试验收阶段:
  - 测试分析: 20轮 × Flash = ~$0.50
  - Bug分析: 5轮 × Opus = ~$1.25
  - Bug修复: Claude Code订阅内
  - UI验收: 10轮 × Sonnet API = ~$1.00
  小计: ~$2.75

辅助功能:
  - 路由分类: 50轮 × Haiku = ~$0.25
  小计: ~$0.25

────────────────────────────────────────────
单项目总计:
  - 分析规划: $3.80
  - 代码开发: $30-50 (订阅分摊)
  - 测试验收: $2.75
  - 辅助: $0.25
  总计: ~$37-57 / 项目
────────────────────────────────────────────
```

### 6.2 月度成本估算

```yaml
假设: Thinkus平台，月活100个项目

固定成本:
  - Claude Code Max 5x: $100/月
  - (如需) Codex Plus: $20/月
  固定总计: $100-120/月

变动成本 (API调用):
  - Gemini 3 Pro分析: 100项目 × $4 = $400
  - Gemini Flash快速: 100项目 × $1 = $100
  - Claude Opus决策: 100项目 × $2 = $200
  - Claude Haiku路由: 100项目 × $0.5 = $50
  - Claude Sonnet验收: 100项目 × $1 = $100
  变动总计: ~$850/月

────────────────────────────────────────────
月度总计: $950-1,000/月 (100个项目)
单项目成本: ~$10/项目
────────────────────────────────────────────

对比纯用Claude API:
  - 全部用Opus: 100 × $50+ = $5,000+/月
  - 节省: 80%+
```

---

## 七、实现代码

### 7.1 多模型调度器

```python
from enum import Enum
from dataclasses import dataclass
import anthropic
import google.generativeai as genai
import openai

class TaskType(Enum):
    # 分析任务 - 用Gemini/Claude API
    REQUIREMENT_ANALYSIS = "requirement_analysis"
    DESIGN_PLANNING = "design_planning"
    ARCHITECTURE_DESIGN = "architecture_design"
    TECH_RESEARCH = "tech_research"
    CODEBASE_ANALYSIS = "codebase_analysis"
    TEST_ANALYSIS = "test_analysis"
    BUG_ANALYSIS = "bug_analysis"
    
    # 代码任务 - 只能用Claude Code或Codex
    CODE_DEVELOPMENT = "code_development"
    CODE_REFACTOR = "code_refactor"
    BUG_FIX = "bug_fix"
    TEST_CODE = "test_code"
    
    # 快速任务 - 用Haiku/Flash
    CLASSIFICATION = "classification"
    ROUTING = "routing"
    SIMPLE_QA = "simple_qa"

class ThinkusModelRouter:
    """Thinkus多模型路由器"""
    
    def __init__(self):
        # 分析模型
        genai.configure(api_key=os.environ["GEMINI_API_KEY"])
        self.claude_api = anthropic.Anthropic()
        
        # 代码开发工具 (订阅制，通过CLI调用)
        self.claude_code_available = True
        self.codex_available = True
    
    # 任务-模型映射
    TASK_MODEL_MAP = {
        # 分析任务 → Gemini 3 Pro
        TaskType.REQUIREMENT_ANALYSIS: ("gemini-3-pro", "gemini"),
        TaskType.DESIGN_PLANNING: ("gemini-3-pro", "gemini"),
        TaskType.TECH_RESEARCH: ("gemini-3-pro", "gemini"),
        TaskType.CODEBASE_ANALYSIS: ("gemini-3-pro", "gemini"),
        TaskType.TEST_ANALYSIS: ("gemini-3-flash", "gemini"),
        
        # 复杂决策 → Claude Opus
        TaskType.ARCHITECTURE_DESIGN: ("claude-opus-4-5", "claude"),
        TaskType.BUG_ANALYSIS: ("claude-opus-4-5", "claude"),
        
        # 代码任务 → Claude Code (订阅)
        TaskType.CODE_DEVELOPMENT: ("claude-code", "claude-code"),
        TaskType.CODE_REFACTOR: ("claude-code", "claude-code"),
        TaskType.BUG_FIX: ("claude-code", "claude-code"),
        TaskType.TEST_CODE: ("claude-code", "claude-code"),
        
        # 快速任务 → Haiku/Flash
        TaskType.CLASSIFICATION: ("claude-haiku-4-5", "claude"),
        TaskType.ROUTING: ("claude-haiku-4-5", "claude"),
        TaskType.SIMPLE_QA: ("gemini-3-flash", "gemini"),
    }
    
    async def execute(self, task_type: TaskType, content: str, **kwargs) -> str:
        model_id, provider = self.TASK_MODEL_MAP[task_type]
        
        if provider == "claude-code":
            return await self._execute_claude_code(content, **kwargs)
        elif provider == "gemini":
            return await self._execute_gemini(model_id, content, **kwargs)
        elif provider == "claude":
            return await self._execute_claude_api(model_id, content, **kwargs)
    
    async def _execute_claude_code(self, content: str, **kwargs) -> str:
        """执行Claude Code (订阅制CLI)"""
        import subprocess
        
        # 检查是否限额
        if self._is_claude_code_limited():
            # 降级到Codex
            if self.codex_available:
                return await self._execute_codex(content, **kwargs)
            # 或用API
            return await self._execute_claude_api(
                "claude-sonnet-4-5", content, **kwargs
            )
        
        # 调用Claude Code CLI
        result = subprocess.run(
            ["claude", "-p", content],
            capture_output=True,
            text=True
        )
        return result.stdout
    
    async def _execute_codex(self, content: str, **kwargs) -> str:
        """执行OpenAI Codex"""
        response = await openai.chat.completions.create(
            model="gpt-5-codex",
            messages=[{"role": "user", "content": content}],
            max_tokens=kwargs.get("max_tokens", 4096)
        )
        return response.choices[0].message.content
    
    async def _execute_gemini(self, model_id: str, content: str, **kwargs) -> str:
        """执行Gemini模型"""
        model = genai.GenerativeModel(model_id)
        
        # 设置思考级别
        thinking_level = kwargs.get("thinking_level", "medium")
        
        response = await model.generate_content_async(
            content,
            generation_config={
                "thinking_level": thinking_level
            }
        )
        return response.text
    
    async def _execute_claude_api(self, model_id: str, content: str, **kwargs) -> str:
        """执行Claude API"""
        response = await self.claude_api.messages.create(
            model=model_id,
            max_tokens=kwargs.get("max_tokens", 4096),
            messages=[{"role": "user", "content": content}]
        )
        return response.content[0].text
    
    def _is_claude_code_limited(self) -> bool:
        """检查Claude Code是否限额"""
        # 实际实现需要跟踪用量
        return False


# 使用示例
router = ThinkusModelRouter()

# 需求分析 → Gemini 3 Pro
result = await router.execute(
    TaskType.REQUIREMENT_ANALYSIS,
    "用户说: 我想做一个电商网站，帮我分析需求"
)

# 架构设计 → Claude Opus
result = await router.execute(
    TaskType.ARCHITECTURE_DESIGN,
    "基于以下需求设计系统架构: ..."
)

# 代码开发 → Claude Code
result = await router.execute(
    TaskType.CODE_DEVELOPMENT,
    "实现用户登录功能，包含邮箱验证"
)

# 快速分类 → Haiku
result = await router.execute(
    TaskType.CLASSIFICATION,
    "判断这个任务的复杂度: ..."
)
```

---

## 八、总结

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     Thinkus 最优模型配置 (修正版)                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  📝 分析规划: Gemini 3 Pro ($2/$12)                                         │
│     • 需求分析、设计规划、技术调研、代码库分析                                │
│     • 1M上下文，多模态，思考能力强                                           │
│                                                                              │
│  🧠 复杂决策: Claude Opus 4.5 ($5/$25)                                      │
│     • 架构设计、疑难Bug分析、重要决策                                        │
│     • 推理最强，一次搞定                                                     │
│                                                                              │
│  💻 代码开发: Claude Code (订阅$100-200/月)                                 │
│     • 所有代码编写、重构、Bug修复、测试代码                                  │
│     • 备选: OpenAI Codex                                                    │
│     • ⚠️ 只能用这两个写代码！                                               │
│                                                                              │
│  ⚡ 快速任务: Haiku ($1/$5) / Gemini Flash ($0.50/$3)                       │
│     • 分类、路由、简单问答、批量分析                                         │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  💰 成本估算:                                                                │
│     • 固定: Claude Code Max 5x = $100/月                                    │
│     • 变动: Gemini + Claude API = ~$850/月 (100项目)                        │
│     • 总计: ~$950-1000/月 (100项目)                                         │
│     • 单项目: ~$10                                                          │
│                                                                              │
│  🔑 核心原则:                                                                │
│     1. 代码开发 → 只用Claude Code或Codex                                    │
│     2. 分析规划 → 用Gemini 3 Pro (便宜+长上下文)                            │
│     3. 复杂决策 → 用Claude Opus (最强推理)                                  │
│     4. 快速任务 → 用Haiku/Flash (便宜快速)                                  │
│     5. Claude Code限额 → 切换到Codex                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```
