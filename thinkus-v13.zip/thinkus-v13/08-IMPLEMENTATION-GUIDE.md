# Thinkus v12 - AI产品开发完整流程

> 给AI工程师的实现指南：从用户需求到产品交付的完整闭环

---

## 〇、历史文档要点整合

> 以下是v11、v12历史文档中的核心设计，必须保留

### 0.0 产品定义 (v11)

```yaml
一句话定义:
  Thinkus = 你的AI创业团队，帮你从想法到产品到赚钱，全程包办

产品定位:
  Thinkus 不是:
    ❌ AI聊天工具 (只能聊天)
    ❌ AI顾问 (只提供建议)
    ❌ SaaS工具 (用户自己做)
  
  Thinkus 是:
    ✅ AI创业团队 (帮你做出来)
    ✅ 全包服务 (从想法到赚钱)
    ✅ 24小时自动运转 (不需要你盯着)

核心价值主张:
  1. 不用学编程，描述想法就能得到产品
  2. 不用招团队，AI高管团队7x24小时服务
  3. 不用懂运营，AI自动帮你推广增长
  4. 不用担心质量，AI自动测试和修复

目标用户:
  主要用户:
    - 非技术创业者: 有想法但不会编程
    - 独立开发者: 想提高效率，专注核心
    - 小团队: 人手不足，需要AI补充
    - 产品经理: 快速验证想法
  
  用户画像:
    - 年龄: 25-45岁
    - 痛点: 有想法但落地难
    - 预算: 愿意为效率付费
    - 期望: 快速看到成果
```

### 0.1 用户专属高管架构 (v11)

```
核心理念: 每个用户拥有专属的18个AI高管实例，数据完全隔离

┌─────────────────────────────────────────────────────────────────────────┐
│                                                                          │
│   用户A                           用户B                                  │
│                                                                          │
│   ┌─────────────────────┐         ┌─────────────────────┐               │
│   │  用户A的Mike实例    │         │  用户B的Mike实例    │               │
│   │  - A的项目历史      │         │  - B的项目历史      │               │
│   │  - A的沟通偏好      │         │  - B的沟通偏好      │               │
│   └─────────────────────┘         └─────────────────────┘               │
│                                                                          │
│   数据隔离层次:                                                          │
│   1. 数据库: 每个文档都有userId字段                                     │
│   2. 向量存储: Pinecone命名空间 user_{userId}_{agentId}                 │
│   3. 应用层: API验证userId                                               │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

### 0.2 双层记忆系统 (v11)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                          │
│   Layer 1: 跨项目记忆 (用户偏好)                                        │
│   ════════════════════════════                                          │
│   - 沟通风格偏好                                                        │
│   - 决策习惯                                                            │
│   - 技术栈偏好                                                          │
│   存储: user_{userId}_{agentId} (无projectId)                           │
│   生命周期: 永久                                                        │
│                                                                          │
│   Layer 2: 项目专属记忆                                                 │
│   ════════════════════════                                              │
│   - 项目决策、讨论结论                                                  │
│   - 技术方案、进度里程碑                                                │
│   存储: user_{userId}_{agentId} (带projectId过滤)                       │
│   生命周期: 项目存在期间                                                │
│                                                                          │
└─────────────────────────────────────────────────────────────────────────┘
```

### 0.3 AI自治运营系统 (v11)

```yaml
核心理念: AI驱动，人确认

四大引擎:
  1. 数据感知引擎: 监控项目相关数据变化
  2. 工作调度引擎: 自动安排任务
  3. 决策分级引擎: 分级决策
  4. 执行追踪引擎: 追踪执行结果

决策分级:
  L0 全自动: Bug修复、性能优化、日常内容
  L1 通知:   新功能上线、营销活动
  L2 确认:   核心变更、大型活动 (48小时超时)
  L3 强制:   安全、法务、大额财务 (72小时超时)
```

### 0.4 邀请码饥饿营销系统 (v11)

```yaml
核心原则:
  1. 极度稀缺: 每天只放出少量邀请码
  2. 申请门槛: 需要申请+审核，不是注册就能用
  3. 社交货币: 有邀请码 = 有身份
  4. 话题制造: "Thinkus邀请码"成为热门话题

新用户流程:
  访问官网 → 填写申请表 → 排队等待 → 审核筛选 → 每日限量释放 → 获得邀请码

老用户邀请:
  - 邀请码数量有限 (初始2个)
  - 成功邀请可获得更多
  - 邀请码是稀缺资源
```

### 0.5 商业模式 (v11)

```yaml
项目定价 (按项目付费):
  种子项目: ¥99/月   - 适合验证想法 (1个项目，基础AI)
  成长项目: ¥299/月  - 适合MVP开发 (3个项目，高级AI)
  规模项目: ¥699/月  - 适合正式产品 (10个项目，全部AI+优先支持)
  企业项目: ¥1499/月 - 适合复杂系统 (无限项目，专属支持)

免费体验:
  - 1个项目，7天有效
  - 基础AI高管可用
  - 体验完整流程

关键指标:
  - 免费→付费转化: > 5%
  - 用户留存 (D30): > 25%
  - ARPU: > ¥200/月
  - 邀请发送率: > 40%
  - 病毒系数K: > 0.7
```

### 0.6 6大优化项 (v12)

```yaml
优化1 - Magic Keyword:
  用户输入"全力"/"gogogo"等关键词
  → 自动启用并行 + Auto-Verify + 不完成不休息

优化2 - Todo Continuation:
  追踪代码中所有TODO
  → 未完成不允许结束任务

优化3 - Comment Checker:
  检查注释质量
  → 让AI生成的代码像人写的

优化4 - Context Window Monitor:
  主动监控上下文大小
  → 提前压缩，避免撞墙

优化5 - Session Recovery:
  自动从各种错误中恢复
  → 网络断开、API超时等

优化6 - Librarian Agent:
  新增研究员角色
  → 专门查文档、找开源实现
```

### 0.7 Manus竞品核心启示 (v12)

```yaml
三大核心设计理念:

1. 一体化价值链:
   研究 → 内容创建 → 构建开发 → 集成扩展 → 部署托管 → 分析迭代
   一个上下文、一个会话、无缝衔接

2. AI能力内嵌:
   不是"帮用户开发产品"
   而是"帮用户开发有AI能力的产品"
   - 智能客服聊天机器人
   - AI内容生成
   - AI图像生成

3. 计划先行+自测闭环:
   开发前先展示计划 → 用户确认 → 开发 → 自动测试 → 自动修复
```

### 0.8 外部专家系统 (v11)

```yaml
20位外部专家 (共享资源，按需咨询):

行业专家:
  - AI/机器学习专家
  - 区块链专家
  - 电商专家
  - SaaS专家
  - 游戏专家
  - 金融科技专家
  - 医疗健康专家
  - 教育科技专家
  
技术专家:
  - 云架构专家
  - 数据库专家
  - 安全专家
  - 性能优化专家
  
商业专家:
  - 融资专家
  - 出海专家
  - 知识产权专家
  - 合规专家

特点:
  - 共享实例，不记住项目细节
  - 按需动态加入讨论
  - 提供通用专业建议
  - 不消耗用户配额

内部高管 vs 外部专家:
  内部高管: 专属实例，记住用户偏好，全程参与
  外部专家: 共享实例，无记忆，按需咨询
```

### 0.9 能力系统 - Skills/Subagents/MCP (v12)

```yaml
三层能力架构:

┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  Layer 3: MCP (外部服务连接)                                                │
│  ─────────────────────────────                                              │
│  连接外部服务和API                                                          │
│  • context7: 官方文档查询                                                   │
│  • grep_app: GitHub代码搜索                                                 │
│  • browser: 浏览器自动化                                                    │
│  • github: 仓库操作                                                         │
│  • vercel: 部署服务                                                         │
│  • stripe: 支付服务                                                         │
│                                                                              │
│  Layer 2: Subagents (子代理并行执行)                                        │
│  ─────────────────────────────────                                          │
│  任务分解 → 并行执行 → 结果汇总                                            │
│  • Frontend Developer: 前端开发子代理                                       │
│  • Backend Developer: 后端开发子代理                                        │
│  • Test Runner: 测试执行子代理                                              │
│  • Code Reviewer: 代码审查子代理                                            │
│                                                                              │
│  Layer 1: Skills (技能知识库)                                               │
│  ────────────────────────────                                               │
│  知识 + 流程 + 模板 + 最佳实践                                             │
│  • code_analysis: 代码分析技能                                              │
│  • react_development: React开发技能                                         │
│  • api_design: API设计技能                                                  │
│  • database_design: 数据库设计技能                                          │
│  • testing: 测试技能                                                        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Skills实现示例：**

```python
class Skill:
    """技能基类"""
    name: str
    description: str
    knowledge: str          # 领域知识
    workflow: str           # 工作流程
    templates: List[str]    # 代码模板
    best_practices: str     # 最佳实践

class CodeAnalysisSkill(Skill):
    name = "code_analysis"
    description = "代码分析和理解"
    
    async def analyze(self, code: str) -> Analysis:
        """分析代码结构、依赖、问题"""
        prompt = f"""
        {self.knowledge}
        
        分析以下代码:
        {code}
        
        输出:
        1. 代码结构
        2. 依赖关系
        3. 潜在问题
        4. 改进建议
        """
        return await self.ai.chat(prompt)
```

**Subagents实现示例：**

```python
class SubagentOrchestrator:
    """子代理编排器"""
    
    async def parallel_develop(self, task: Task) -> Result:
        """并行开发"""
        
        # 1. 分解任务
        subtasks = await self.decompose(task)
        
        # 2. 分配给子代理并行执行
        results = await asyncio.gather(
            self.frontend_agent.execute(subtasks['frontend']),
            self.backend_agent.execute(subtasks['backend']),
            self.test_agent.execute(subtasks['test']),
        )
        
        # 3. 汇总结果
        return await self.merge_results(results)
```

**MCP集成示例：**

```python
class MCPClient:
    """MCP服务客户端"""
    
    async def call_context7(self, query: str) -> str:
        """查询官方文档"""
        return await self.mcp.call('context7', {'query': query})
    
    async def call_github(self, action: str, params: dict) -> dict:
        """GitHub操作"""
        return await self.mcp.call('github', {'action': action, **params})
    
    async def call_vercel(self, action: str, params: dict) -> dict:
        """Vercel部署"""
        return await self.mcp.call('vercel', {'action': action, **params})
```

---

## 一、系统概览

### 1.1 核心理念

```
用户说一句话 → AI团队自动完成 → 交付可用产品

关键词：
├── 设计先行 (先看到再开发)
├── 契约驱动 (接口定义先于开发)
├── 双重验收 (功能+体验)
├── 持续反馈 (用户全程参与)
└── 知识积累 (越用越好)
```

### 1.2 AI高管团队 (18位完整定义)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                         Thinkus AI 高管团队 (18位)                          │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        核心管理层 (6位)                              │   │
│  │                                                                      │   │
│  │  👔 Mike (PM总监)     - 需求分析、产品规划、PRD编写                  │   │
│  │  👩‍💻 David (技术总监)  - 架构设计、技术选型、代码审查                │   │
│  │  👩‍🎨 Elena (UX总监)    - 界面设计、交互设计、用户体验                │   │
│  │  📊 Marcus (CMO)      - 市场策略、品牌定位、增长运营                  │   │
│  │  💰 Sarah (CFO)       - 财务规划、成本控制、商业模式                  │   │
│  │  ⚖️ James (法务总监)  - 合规审查、隐私政策、合同条款                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       技术专家组 (6位)                               │   │
│  │                                                                      │   │
│  │  🔧 Frank (DevOps)    - CI/CD、部署运维、监控告警                    │   │
│  │  🛡️ Grace (安全专家)  - 安全审计、漏洞修复、数据保护                  │   │
│  │  📱 Henry (移动端)    - iOS/Android开发、跨平台方案                   │   │
│  │  🤖 Ivan (AI/ML)      - AI功能集成、模型选型、智能优化                │   │
│  │  🏗️ Jack (架构师)     - 系统设计、性能优化、技术债务                  │   │
│  │  🔬 Kevin (QA总监)    - 测试策略、质量保障、自动化测试                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       业务专家组 (5位)                               │   │
│  │                                                                      │   │
│  │  📈 Lisa (数据分析)   - 数据洞察、报表设计、决策支持                  │   │
│  │  🎯 Nancy (销售总监)  - 销售策略、客户转化、定价建议                  │   │
│  │  💼 Oscar (BD总监)    - 合作伙伴、渠道拓展、商务谈判                  │   │
│  │  📢 Paul (PR总监)     - 公关传播、媒体关系、危机处理                  │   │
│  │  🤝 Quinn (HR总监)    - 团队建设、招聘建议、文化塑造                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       特殊角色 (1位)                                 │   │
│  │                                                                      │   │
│  │  📚 Librarian (研究员) - 技术调研、文档查找、开源方案推荐            │   │
│  │     (不写代码，专门做信息收集和技术研究)                             │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

**核心高管详细人设：**

```yaml
Mike (PM总监):
  ID: mike_pm
  模型: claude-sonnet-4-20250514
  人设: 15年产品经验，Google/Meta背景，沟通直接有条理
  专长: 需求分析、优先级排序、PRD编写、竞品分析
  触发: 用户描述想法、需要梳理需求、编写文档
  风格: "让我帮你理清这个需求。首先，核心用户是谁？"

David (技术总监):
  ID: david_tech
  模型: claude-sonnet-4-20250514
  人设: 20年技术经验，Amazon/Stripe背景，追求简洁可扩展
  专长: 架构设计、技术选型、代码审查、性能优化
  触发: 技术方案讨论、代码问题、架构决策
  风格: "从架构角度看，这里有几个考量点..."

Elena (UX总监):
  ID: elena_ux
  模型: claude-sonnet-4-20250514
  人设: 12年设计经验，IDEO/Apple背景，对细节极度关注
  专长: 界面设计、交互设计、用户研究、设计系统
  触发: 界面设计、用户体验、视觉效果
  风格: "从用户角度，这个流程可能让人困惑..."

Kevin (QA总监):
  ID: kevin_qa
  模型: claude-sonnet-4-20250514
  人设: 10年QA经验，测试驱动开发倡导者
  专长: 测试策略、自动化测试、边界测试、集成测试
  触发: 代码完成后、需要验证、发现bug
  风格: "我来验证一下这个实现。首先检查边界情况..."

Librarian (研究员):
  ID: librarian
  模型: claude-sonnet-4-20250514
  人设: 技术研究员，不写代码，专做信息收集
  专长: 技术调研、文档查找、开源方案、最佳实践
  触发: 需要技术调研、找参考实现、查文档
  风格: "我找到几个相关的开源实现和文档..."
```

### 1.3 技术栈

```yaml
前端:
  框架: Next.js 14 (App Router)
  语言: TypeScript
  样式: TailwindCSS
  组件库: shadcn/ui
  状态管理: Zustand
  实时通信: Socket.io / WebSocket
  代码编辑: Monaco Editor

后端 (三层架构):
  Node.js层 (现有):
    框架: Next.js API Routes + tRPC
    认证: NextAuth.js
    任务队列: BullMQ
    
  Go层 (编排):
    框架: Gin / Fiber
    通信: gRPC
    调度: goroutine并发
    
  Python层 (AI执行):
    框架: FastAPI
    AI SDK: Anthropic SDK
    浏览器: Playwright / Browser Use
    测试: pytest

数据存储:
  主数据库: PostgreSQL (结构化数据)
  缓存: Redis (会话、队列)
  向量库: Pinecone (记忆检索)
  文件存储: Cloudflare R2 / S3

AI模型:
  核心分析: Claude Opus (重要决策)
  常规任务: Claude Sonnet (日常开发)
  快速判断: Claude Haiku (调度、分类)

监控分析:
  用户行为: PostHog
  错误追踪: Sentry
  日志: 自建 / Datadog

部署:
  平台: Vercel (前端) + Railway/Fly.io (后端)
  容器: Docker + Kubernetes
  CDN: Cloudflare
```

### 1.4 核心数据类型

```typescript
// 高管ID类型
type AgentId = 
  | 'mike_pm' | 'david_tech' | 'elena_ux' | 'marcus_cmo' | 'sarah_cfo' | 'james_legal'
  | 'frank_devops' | 'grace_security' | 'henry_mobile' | 'ivan_ai' | 'jack_architect' | 'kevin_qa'
  | 'lisa_data' | 'nancy_sales' | 'oscar_bd' | 'paul_pr' | 'quinn_hr'
  | 'librarian'

// 项目阶段
type ProjectPhase = 'ideation' | 'definition' | 'design' | 'development' | 'prelaunch' | 'growth'

// 决策级别
type DecisionLevel = 'L0' | 'L1' | 'L2' | 'L3'
// L0: 全自动 (Bug修复、日常优化)
// L1: 通知用户 (新功能上线)
// L2: 需要确认 (核心变更，48小时超时)
// L3: 强制确认 (安全/法务/财务，72小时超时)

// 记忆类型
type MemoryType = 
  | 'user_preference'        // 用户偏好
  | 'project_decision'       // 项目决策
  | 'discussion_conclusion'  // 讨论结论
  | 'technical_choice'       // 技术选型
  | 'feedback'               // 用户反馈
  | 'long_term'              // 长期记忆
  | 'short_term'             // 短期记忆
```

---

## 二、完整流程 (8个阶段)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐
│  │  1  │ → │  2  │ → │  3  │ → │  4  │ → │  5  │ → │  6  │ → │  7  │ → │  8  │
│  │需求 │   │设计 │   │架构 │   │开发 │   │测试 │   │验收 │   │部署 │   │运维 │
│  │分析 │   │确认 │   │规划 │   │实现 │   │验证 │   │交付 │   │上线 │   │支持 │
│  └─────┘   └─────┘   └─────┘   └─────┘   └─────┘   └─────┘   └─────┘   └─────┘
│                                                                              │
│  用户参与点: ✓确认    ✓确认    ✓确认    可预览    可预览   ✓验收    ✓确认     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 三、阶段1: 需求分析 (Mike)

### 3.1 输入输出

```
输入: 用户一句话需求 "帮我做一个电商网站"
输出: 
  ├── 功能列表 (Feature List)
  ├── 依赖关系图
  ├── 迭代计划
  └── 预估时间
```

### 3.2 Mike分析流程

```python
class MikeRequirementAnalyzer:
    
    async def analyze(self, requirement: str) -> ProductPlan:
        # 1. 查询知识库，是否有类似项目模板
        template = await self.knowledge_base.find_similar(requirement)
        
        # 2. 提取功能点
        features = await self._extract_features(requirement, template)
        
        # 3. 分析依赖关系
        dependencies = await self._analyze_dependencies(features)
        
        # 4. 划分迭代 (每个迭代3-5个功能)
        iterations = await self._plan_iterations(features, dependencies)
        
        # 5. 估算时间
        estimate = await self._estimate_time(iterations)
        
        return ProductPlan(
            features=features,
            dependencies=dependencies,
            iterations=iterations,
            estimated_minutes=estimate
        )
```

### 3.3 数据结构

```python
@dataclass
class Feature:
    id: str                      # F001
    name: str                    # 用户登录
    description: str             # 详细描述
    module: str                  # 用户管理
    involves: List[str]          # [frontend, backend, database]
    complexity: str              # simple/medium/complex
    dependencies: List[str]      # [F001]
    estimated_minutes: int       # 15

@dataclass
class Iteration:
    id: str
    name: str
    goal: str
    features: List[str]          # Feature IDs
    estimated_minutes: int

@dataclass
class ProductPlan:
    requirement: str
    features: List[Feature]
    iterations: List[Iteration]
    total_minutes: int
```

### 3.4 用户确认

```
Mike: "我分析了您的需求，电商网站需要11个功能：

用户模块: 注册、登录、个人中心
商品模块: 列表、详情、搜索
购物模块: 购物车、下单、支付、订单管理

分4个迭代开发，预计80分钟。

[确认] [修改需求] [添加功能] [删除功能]"
```

---

## 四、阶段2: 设计确认 (Elena)

### 4.1 核心理念

```
❌ 错误: 需求确认 → 直接开发 → 做完用户说不对
✅ 正确: 需求确认 → 设计稿 → 用户确认 → 开发
```

### 4.2 Elena设计流程

```python
class ElenaDesigner:
    
    async def design_feature(self, feature: Feature, design_tokens: DesignTokens) -> DesignOutput:
        """为功能生成设计预览"""
        
        # 1. 生成预览组件代码 (React + TailwindCSS)
        preview_code = await self._generate_preview_code(feature, design_tokens)
        
        # 2. 在沙盒中渲染并截图
        preview_result = await self._render_in_sandbox(preview_code)
        
        # 3. 输出
        return DesignOutput(
            feature_id=feature.id,
            preview_code=preview_code,         # 可复用的代码
            preview_url=preview_result.url,    # 实时预览链接
            preview_image=preview_result.screenshot,  # 截图
            design_tokens=design_tokens
        )
    
    async def _generate_preview_code(self, feature: Feature, tokens: DesignTokens) -> str:
        """生成预览组件代码"""
        
        prompt = f"""为以下功能生成预览页面代码：

功能: {feature.name}
描述: {feature.description}

设计规范:
- 主色: {tokens.colors['primary']}
- 字体: {tokens.typography['font_family']}
- 圆角: {tokens.radius['md']}

要求:
1. 使用React + TailwindCSS
2. 包含所有状态展示 (默认/加载/成功/错误)
3. 响应式设计 (手机/桌面)
4. 使用Mock数据展示效果
5. 代码可直接运行预览

生成完整的单文件React组件。"""
        
        return await self.ai.chat('elena_ux', prompt)
    
    async def _render_in_sandbox(self, code: str) -> PreviewResult:
        """在沙盒中渲染预览"""
        
        # 1. 创建预览项目
        preview_html = f"""
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        {code}
        ReactDOM.render(<Preview />, document.getElementById('root'));
    </script>
</body>
</html>
"""
        
        # 2. 写入沙盒
        await self.sandbox.files.write('/preview/index.html', preview_html)
        
        # 3. 启动预览服务
        preview_url = await self.sandbox.start_preview_server('/preview', port=3000)
        
        # 4. 使用Browser Use截图
        browser = Browser(headless=True)
        agent = Agent(
            task=f"打开 {preview_url}，等待页面加载完成，截图",
            llm=self.llm,
            browser=browser,
            save_screenshots=True
        )
        result = await agent.run()
        
        return PreviewResult(
            url=preview_url,
            screenshot=result.screenshots[-1]
        )
```

### 4.3 预览方式

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│                       设计预览方式                                           │
│                                                                              │
│  方式1: 截图 (推荐)                                                         │
│  ─────────────────                                                          │
│  Elena生成React代码 → 沙盒渲染 → Browser Use截图 → 展示给用户              │
│  优点: 用户直接看图，简单直观                                               │
│                                                                              │
│  方式2: 实时预览链接                                                        │
│  ─────────────────────                                                      │
│  Elena生成React代码 → 沙盒渲染 → 返回预览URL → 用户点击查看                │
│  优点: 用户可以交互，体验真实效果                                           │
│                                                                              │
│  方式3: 嵌入式预览 (iframe)                                                 │
│  ─────────────────────────                                                  │
│  在Thinkus界面中嵌入iframe展示预览                                          │
│  优点: 无需跳转，体验流畅                                                   │
│                                                                              │
│  实际使用: 三种方式都提供                                                   │
│  ├── 默认展示截图                                                           │
│  ├── 点击可打开实时预览                                                     │
│  └── 在侧边栏嵌入iframe预览                                                 │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.4 预览代码复用

```python
class DesignToCodeReuse:
    """预览代码复用到正式开发"""
    
    async def convert_preview_to_production(self, preview_code: str, contract: InterfaceContract) -> str:
        """将预览代码转换为正式代码"""
        
        prompt = f"""将以下预览组件转换为正式生产代码：

预览代码 (使用Mock数据):
{preview_code}

接口契约:
- API: {contract.api}
- 状态管理: {contract.frontend['states']}
- 错误处理: {contract.api['errors']}

转换要求:
1. 将Mock数据替换为真实API调用
2. 添加完整的错误处理
3. 添加加载状态
4. 添加表单验证
5. 保持UI样式不变

生成正式的React组件代码。"""
        
        return await self.ai.chat('elena_ux', prompt)

# 流程:
# 1. Elena生成预览代码 (Mock数据)
# 2. 用户确认设计
# 3. Elena将预览代码转换为正式代码 (真实API)
# 4. UI样式100%复用，只改数据逻辑
```

### 4.3 设计规范 (Design Tokens)

```python
@dataclass
class DesignTokens:
    """整个项目统一的设计规范"""
    
    # 颜色
    colors: dict = {
        'primary': '#3B82F6',
        'secondary': '#10B981',
        'error': '#EF4444',
        'warning': '#F59E0B',
        'background': '#FFFFFF',
        'text': '#1F2937',
        'text_secondary': '#6B7280',
    }
    
    # 字体
    typography: dict = {
        'font_family': 'Inter, sans-serif',
        'h1': '2.25rem/700',
        'h2': '1.875rem/600',
        'h3': '1.5rem/600',
        'body': '1rem/400',
        'small': '0.875rem/400',
    }
    
    # 间距
    spacing: dict = {
        'xs': '0.25rem',
        'sm': '0.5rem',
        'md': '1rem',
        'lg': '1.5rem',
        'xl': '2rem',
    }
    
    # 圆角
    radius: dict = {
        'sm': '0.25rem',
        'md': '0.375rem',
        'lg': '0.5rem',
        'full': '9999px',
    }
```

### 4.4 用户确认设计

```
Elena: "这是登录页面的设计预览：

[显示设计稿图片]

设计说明：
• 简洁的居中布局
• 邮箱和密码输入框
• 主色调登录按钮
• 底部有注册链接
• 支持GitHub登录

[确认设计] [修改颜色] [调整布局] [重新设计]"
```

---

## 五、阶段3: 架构规划 (David + Sam)

### 5.1 技术选型

```python
class DavidArchitect:
    
    async def design_architecture(self, plan: ProductPlan) -> Architecture:
        # 1. 根据功能选择技术栈
        tech_stack = await self._select_tech_stack(plan.features)
        
        # 2. 设计目录结构
        structure = await self._design_structure(tech_stack)
        
        # 3. 定义组件库
        components = await self._define_components(plan.features)
        
        return Architecture(
            tech_stack=tech_stack,
            structure=structure,
            components=components
        )
```

### 5.2 数据库设计

```python
class SamDatabaseDesigner:
    
    async def design_schema(self, plan: ProductPlan) -> DatabaseSchema:
        # 1. 根据功能提取实体
        entities = await self._extract_entities(plan.features)
        
        # 2. 设计表结构
        tables = await self._design_tables(entities)
        
        # 3. 设计关系
        relations = await self._design_relations(tables)
        
        # 4. 生成Migration
        migrations = await self._generate_migrations(tables, relations)
        
        return DatabaseSchema(
            tables=tables,
            relations=relations,
            migrations=migrations
        )
```

### 5.3 组件库定义

```python
@dataclass
class ComponentLibrary:
    """预定义的可复用组件"""
    
    components: List[Component] = [
        Component(name='Button', variants=['primary', 'secondary', 'danger']),
        Component(name='Input', variants=['text', 'password', 'email']),
        Component(name='Card', variants=['default', 'hover', 'selected']),
        Component(name='Modal', variants=['default', 'confirm', 'alert']),
        Component(name='Table', variants=['default', 'sortable', 'paginated']),
        Component(name='Form', variants=['default', 'inline']),
        Component(name='Loading', variants=['spinner', 'skeleton', 'progress']),
        Component(name='Toast', variants=['success', 'error', 'warning', 'info']),
    ]
```

---

## 六、阶段4: 开发实现

### 6.1 单个功能开发流程

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  功能开发流程 (每个功能)                                                    │
│                                                                              │
│  ┌─────────────┐                                                            │
│  │ Mike生成    │                                                            │
│  │ 接口契约    │                                                            │
│  └──────┬──────┘                                                            │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      基于契约并行开发                                │   │
│  │                                                                      │   │
│  │   ┌─────────┐      ┌─────────┐      ┌─────────┐                    │   │
│  │   │  Sam    │      │ David   │      │ Elena   │                    │   │
│  │   │ 数据库  │      │  后端   │      │  前端   │                    │   │
│  │   └────┬────┘      └────┬────┘      └────┬────┘                    │   │
│  │        │                │                │                          │   │
│  │        ▼                ▼                ▼                          │   │
│  │   migration         API代码          React组件                      │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│         │                                                                    │
│         ▼                                                                    │
│  ┌─────────────┐      ┌─────────────┐                                      │
│  │ Kevin       │ ──→  │ Mike        │                                      │
│  │ 功能测试    │      │ UI验收      │                                      │
│  └─────────────┘      └─────────────┘                                      │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 接口契约

```python
@dataclass
class InterfaceContract:
    """接口契约 - 各模块开发的依据"""
    
    feature_id: str
    feature_name: str
    
    # API定义
    api: APIContract = {
        'method': 'POST',
        'path': '/api/auth/login',
        'request': {
            'email': 'string, required',
            'password': 'string, required',
        },
        'response': {
            'token': 'string',
            'user': {'id': 'string', 'email': 'string', 'name': 'string'}
        },
        'errors': [
            {'code': 'INVALID_CREDENTIALS', 'message': '邮箱或密码错误'},
            {'code': 'USER_NOT_FOUND', 'message': '用户不存在'},
        ]
    }
    
    # 数据库定义
    database: DatabaseContract = {
        'table': 'users',
        'fields': {
            'id': 'uuid PRIMARY KEY',
            'email': 'varchar(255) UNIQUE NOT NULL',
            'password_hash': 'varchar(255) NOT NULL',
            'name': 'varchar(100)',
            'created_at': 'timestamp DEFAULT NOW()',
        },
        'indexes': ['email']
    }
    
    # 前端定义
    frontend: FrontendContract = {
        'page': '/login',
        'components': ['LoginForm', 'ErrorMessage'],
        'form_fields': ['email', 'password'],
        'states': ['idle', 'loading', 'success', 'error'],
        'error_handling': ['INVALID_CREDENTIALS', 'USER_NOT_FOUND'],
    }
```

### 6.3 代码生成

```python
class ContractBasedDeveloper:
    """基于契约的代码生成"""
    
    async def develop_database(self, contract: InterfaceContract) -> str:
        """Sam: 生成数据库Migration"""
        
        prompt = f"""基于契约生成Prisma Migration:

表: {contract.database['table']}
字段: {contract.database['fields']}
索引: {contract.database['indexes']}

生成 schema.prisma 和 migration.sql"""
        
        return await self.ai.chat('sam_db', prompt)
    
    async def develop_backend(self, contract: InterfaceContract) -> str:
        """David: 生成后端API"""
        
        prompt = f"""基于契约生成Node.js API:

路径: {contract.api['method']} {contract.api['path']}
请求: {contract.api['request']}
响应: {contract.api['response']}
错误: {contract.api['errors']}
数据库表: {contract.database['table']}

要求:
1. 使用Express
2. 参数校验
3. 错误处理完整
4. 连接数据库

生成完整可运行的代码。"""
        
        return await self.ai.chat('david_tech', prompt)
    
    async def develop_frontend(self, contract: InterfaceContract, design: DesignSpec) -> str:
        """Elena: 生成前端组件"""
        
        prompt = f"""基于契约和设计稿生成React组件:

页面: {contract.frontend['page']}
设计规范: {design}
API调用: {contract.api['method']} {contract.api['path']}
请求参数: {contract.api['request']}
错误处理: {contract.api['errors']}
状态: {contract.frontend['states']}

要求:
1. 使用React + TailwindCSS
2. 遵循设计规范(颜色/字体/间距)
3. 完整的状态处理(loading/success/error)
4. 所有错误码都有友好提示
5. 复用组件库中的组件

生成完整的组件代码。"""
        
        return await self.ai.chat('elena_ux', prompt)
```

### 6.4 并行开发控制

```python
class ParallelDevelopmentController:
    """并行开发控制器"""
    
    async def develop_iteration(self, iteration: Iteration) -> IterationResult:
        """开发一个迭代"""
        
        # 1. 按依赖分组
        groups = self._group_by_dependency(iteration.features)
        
        # 2. 逐组开发 (组内并行，组间串行)
        for group in groups:
            # 组内功能并行开发
            tasks = [self._develop_feature(f) for f in group]
            results = await asyncio.gather(*tasks)
            
            # 等待该组全部完成再继续下一组
            
        # 3. 集成
        await self._integrate_code(iteration)
        
        return IterationResult(iteration.id, success=True)
    
    async def _develop_feature(self, feature: Feature) -> FeatureResult:
        """开发单个功能"""
        
        # 1. 生成契约
        contract = await self.mike.generate_contract(feature)
        
        # 2. 并行开发各模块
        db_task = self.sam.develop(contract)
        api_task = self.david.develop(contract)
        ui_task = self.elena.develop(contract, feature.design)
        
        db_code, api_code, ui_code = await asyncio.gather(
            db_task, api_task, ui_task
        )
        
        # 3. Kevin验证
        test_result = await self.kevin.test(contract, {
            'database': db_code,
            'backend': api_code,
            'frontend': ui_code,
        })
        
        # 4. 修复问题 (最多3次)
        attempts = 0
        while not test_result.success and attempts < 3:
            fixed_code = await self._fix_issues(test_result.issues)
            test_result = await self.kevin.test(contract, fixed_code)
            attempts += 1
        
        # 5. Mike UI验收
        if test_result.success:
            acceptance = await self.mike.accept_ui(feature, contract)
            if not acceptance.passed:
                # UI问题返回Elena修复
                fixed_ui = await self.elena.fix_ui(acceptance.issues)
                # 再次验收...
        
        return FeatureResult(feature.id, success=True)
```

---

## 七、阶段5: 测试验证 (Kevin)

### 7.1 测试类型

```python
class KevinTester:
    """Kevin的测试能力"""
    
    async def full_test(self, contract: InterfaceContract, code: dict) -> TestResult:
        """完整测试"""
        
        results = {}
        
        # 1. 契约一致性测试
        results['contract'] = await self._test_contract_compliance(contract, code)
        
        # 2. 功能测试 (正常流程)
        results['functional'] = await self._test_functional(contract, code)
        
        # 3. 边界测试
        results['boundary'] = await self._test_boundary(contract, code)
        
        # 4. 异常测试
        results['exception'] = await self._test_exception(contract, code)
        
        # 5. 集成测试
        results['integration'] = await self._test_integration(code)
        
        return TestResult(
            success=all(r.success for r in results.values()),
            details=results
        )
```

### 7.2 边界测试

```python
async def _test_boundary(self, contract: InterfaceContract, code: dict) -> TestResult:
    """边界情况测试"""
    
    test_cases = [
        # 空输入
        {'email': '', 'password': ''},
        # 超长输入
        {'email': 'a' * 1000, 'password': 'b' * 1000},
        # 特殊字符
        {'email': "test'@test.com", 'password': '<script>alert(1)</script>'},
        # 空格
        {'email': '  test@test.com  ', 'password': '  password  '},
        # Unicode
        {'email': 'test@测试.com', 'password': '密码123'},
    ]
    
    results = []
    for case in test_cases:
        result = await self._run_test(contract.api, case)
        results.append(result)
    
    return TestResult(success=all(r.handled_gracefully for r in results))
```

### 7.3 异常测试

```python
async def _test_exception(self, contract: InterfaceContract, code: dict) -> TestResult:
    """异常情况测试"""
    
    scenarios = [
        # 网络超时
        {'scenario': 'network_timeout', 'expected': '显示重试提示'},
        # 服务器错误
        {'scenario': 'server_500', 'expected': '显示友好错误信息'},
        # 数据库连接失败
        {'scenario': 'db_connection_failed', 'expected': '优雅降级'},
        # 并发请求
        {'scenario': 'concurrent_requests', 'expected': '正确处理'},
    ]
    
    results = []
    for scenario in scenarios:
        result = await self._simulate_scenario(scenario)
        results.append(result)
    
    return TestResult(success=all(r.passed for r in results))
```

---

## 八、阶段6: UI验收 (Mike + Browser Use)

### 8.1 验收流程

```python
class MikeUIAcceptance:
    """Mike的UI验收 - 基于Browser Use"""
    
    def __init__(self):
        self.llm = ChatAnthropic(model="claude-sonnet-4-20250514")
    
    async def accept_feature(self, feature: Feature, sandbox: Sandbox) -> AcceptanceResult:
        """验收单个功能"""
        
        browser = Browser(headless=True)
        
        # 1. 生成验收任务
        task = await self._generate_acceptance_task(feature)
        
        # 2. 执行验收 (Browser Use)
        agent = Agent(
            task=task,
            llm=self.llm,
            browser=browser,
            save_screenshots=True
        )
        result = await agent.run()
        
        # 3. 分析结果
        evaluation = await self._evaluate(feature, result)
        
        return AcceptanceResult(
            passed=evaluation.score >= 7,
            score=evaluation.score,
            issues=evaluation.issues,
            suggestions=evaluation.suggestions,
            screenshots=result.screenshots
        )
    
    async def _generate_acceptance_task(self, feature: Feature) -> str:
        """生成验收任务 (自然语言)"""
        
        return f"""
作为产品经理验收「{feature.name}」功能：

1. 打开页面 {feature.design.page}
2. 检查界面:
   - 布局是否与设计稿一致
   - 所有元素是否存在
   - 颜色/字体是否正确
3. 测试交互:
   - 正常流程是否顺畅
   - 加载状态是否有提示
   - 错误提示是否友好
4. 检查细节:
   - 按钮大小是否易于点击 (>=44px)
   - 表单验证是否及时
   - 响应速度是否可接受

每步截图，最后给出:
- 评分 (1-10)
- 问题列表
- 改进建议
"""
    
    async def accept_iteration(self, iteration: Iteration, sandbox: Sandbox) -> AcceptanceResult:
        """验收整个迭代 - 用户旅程测试"""
        
        journey = await self._generate_user_journey(iteration)
        
        agent = Agent(
            task=journey,
            llm=self.llm,
            browser=Browser(headless=True),
            save_screenshots=True
        )
        result = await agent.run()
        
        return await self._evaluate_journey(iteration, result)
```

### 8.2 验收标准

```python
ACCEPTANCE_CRITERIA = {
    '布局': [
        '页面结构清晰',
        '重要内容突出',
        '对齐整齐',
        '间距合理',
    ],
    '交互': [
        '按钮可点击且明显 (>=44px)',
        '表单易于填写',
        '加载状态有提示',
        '操作反馈及时 (<200ms)',
    ],
    '体验': [
        '流程顺畅无卡顿',
        '无迷惑的地方',
        '错误提示友好',
        '符合用户预期',
    ],
    '完整性': [
        '所有需求功能都有',
        '边界情况有考虑',
        '必要说明存在',
    ],
}

SCORE_STANDARD = {
    10: '完美，超出预期',
    9: '优秀，几乎没问题',
    8: '良好，小问题不影响',
    7: '合格，能用但可改进',  # 最低通过线
    6: '勉强，需修复才能上线',
    5: '不合格，需要重做',
}
```

---

## 九、阶段7&8: 部署与运维

### 9.1 一键部署

```python
class DeploymentManager:
    """部署管理"""
    
    async def deploy(self, project_id: str, target: str = 'vercel') -> DeployResult:
        """一键部署"""
        
        if target == 'vercel':
            return await self._deploy_to_vercel(project_id)
        elif target == 'netlify':
            return await self._deploy_to_netlify(project_id)
        elif target == 'docker':
            return await self._deploy_to_docker(project_id)
    
    async def _deploy_to_vercel(self, project_id: str) -> DeployResult:
        """部署到Vercel (使用Browser Use)"""
        
        agent = Agent(
            task=f"""
            1. 打开 vercel.com/new
            2. 导入GitHub仓库: {repo_url}
            3. 配置环境变量
            4. 点击Deploy
            5. 等待部署完成
            6. 返回部署URL
            """,
            llm=self.llm,
            browser=Browser()
        )
        result = await agent.run()
        
        return DeployResult(url=result.final_url)
```

### 9.2 监控告警

```python
class MonitoringSetup:
    """监控配置"""
    
    async def setup(self, deploy_url: str):
        # 1. 健康检查
        await self._setup_health_check(deploy_url)
        
        # 2. 错误追踪 (Sentry)
        await self._setup_error_tracking(deploy_url)
        
        # 3. 性能监控
        await self._setup_performance_monitoring(deploy_url)
        
        # 4. 告警通知
        await self._setup_alerts(deploy_url)
```

---

## 十、错误处理与恢复

### 10.1 失败重试策略

```python
class ErrorRecoveryManager:
    """错误恢复管理"""
    
    async def handle_failure(self, failure: Failure) -> RecoveryAction:
        """处理失败"""
        
        # 1. 分析失败原因
        analysis = await self._analyze_failure(failure)
        
        # 2. 决定恢复策略
        if analysis.is_transient:
            # 临时错误，重试
            return RecoveryAction(type='retry', max_attempts=3)
        
        elif analysis.is_fixable:
            # 可修复，让对应AI修复
            return RecoveryAction(
                type='fix',
                assignee=analysis.responsible_ai,
                instructions=analysis.fix_instructions
            )
        
        elif analysis.needs_human:
            # 需要人工介入
            return RecoveryAction(
                type='human_intervention',
                reason=analysis.reason
            )
        
        else:
            # 无法恢复，跳过该功能
            return RecoveryAction(
                type='skip',
                reason=analysis.reason
            )
    
    async def retry_with_backoff(self, task: Callable, max_attempts: int = 3):
        """指数退避重试"""
        
        for attempt in range(max_attempts):
            try:
                return await task()
            except Exception as e:
                if attempt == max_attempts - 1:
                    raise
                wait_time = 2 ** attempt  # 1s, 2s, 4s
                await asyncio.sleep(wait_time)
```

### 10.2 人工介入机制

```python
class HumanInterventionManager:
    """人工介入管理"""
    
    async def request_intervention(self, reason: str, context: dict) -> InterventionResult:
        """请求人工介入"""
        
        # 1. 暂停当前任务
        await self._pause_current_task()
        
        # 2. 通知用户
        await self._notify_user(
            message=f"需要您的帮助: {reason}",
            context=context,
            options=['手动修复', '跳过此功能', '终止开发']
        )
        
        # 3. 等待用户响应
        response = await self._wait_for_user_response()
        
        # 4. 执行用户选择
        return await self._execute_user_choice(response)
```

### 10.3 功能跳过机制

```python
async def skip_feature(self, feature: Feature, reason: str):
    """跳过某个功能"""
    
    # 1. 记录跳过原因
    await self._log_skip(feature, reason)
    
    # 2. 更新依赖图 (跳过依赖该功能的其他功能)
    affected = self._find_dependent_features(feature)
    
    # 3. 通知用户
    await self._notify_user(
        message=f"功能「{feature.name}」已跳过: {reason}",
        affected_features=affected
    )
    
    # 4. 继续其他功能
    return
```

---

## 十一、知识积累

### 11.1 知识库结构

```python
class KnowledgeBase:
    """知识库"""
    
    # 项目模板
    project_templates: List[ProjectTemplate] = []
    # 如: 电商网站模板、博客模板、SaaS模板
    
    # 功能模板
    feature_templates: List[FeatureTemplate] = []
    # 如: 用户认证、支付集成、文件上传
    
    # 代码模板
    code_templates: List[CodeTemplate] = []
    # 如: CRUD API、表单组件、列表页面
    
    # 错误案例
    error_cases: List[ErrorCase] = []
    # 记录常见错误和解决方案
    
    # 最佳实践
    best_practices: List[BestPractice] = []
    # 如: 密码加密、SQL注入防护、XSS防护
```

### 11.2 学习机制

```python
class LearningManager:
    """学习管理"""
    
    async def learn_from_project(self, project: Project):
        """从完成的项目学习"""
        
        # 1. 提取成功模式
        patterns = await self._extract_patterns(project)
        
        # 2. 记录错误案例
        errors = await self._extract_errors(project)
        
        # 3. 更新模板库
        await self._update_templates(patterns)
        
        # 4. 更新错误库
        await self._update_error_cases(errors)
    
    async def find_similar(self, requirement: str) -> Optional[ProjectTemplate]:
        """查找相似项目模板"""
        
        # 向量相似度搜索
        embedding = await self._embed(requirement)
        similar = await self._vector_search(embedding)
        
        return similar
```

---

## 十二、用户交互界面

### 12.1 实时进度展示

```python
class ProgressReporter:
    """进度报告"""
    
    async def report(self, event: ProgressEvent):
        """报告进度"""
        
        await self._send_to_user({
            'type': 'progress',
            'phase': event.phase,           # 当前阶段
            'feature': event.feature,       # 当前功能
            'step': event.step,             # 当前步骤
            'progress': event.progress,     # 百分比
            'message': event.message,       # 描述
            'preview_url': event.preview,   # 预览链接
        })
```

### 12.2 用户反馈处理

```python
class FeedbackHandler:
    """用户反馈处理"""
    
    async def handle_feedback(self, feedback: UserFeedback):
        """处理用户反馈"""
        
        if feedback.type == 'modify_requirement':
            # 修改需求
            await self._handle_requirement_change(feedback)
            
        elif feedback.type == 'design_feedback':
            # 设计反馈
            await self._handle_design_feedback(feedback)
            
        elif feedback.type == 'skip_feature':
            # 跳过功能
            await self._handle_skip_feature(feedback)
            
        elif feedback.type == 'stop_development':
            # 停止开发
            await self._handle_stop(feedback)
```

---

## 十三、完整流程图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  用户: "帮我做一个电商网站"                                                 │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                              │
│  阶段1: 需求分析 (Mike)                                                     │
│  ├── 查询知识库 → 找到电商模板                                              │
│  ├── 提取功能点 → 11个功能                                                  │
│  ├── 分析依赖 → 依赖关系图                                                  │
│  ├── 划分迭代 → 4个迭代                                                     │
│  └── 用户确认 ✓                                                             │
│                                                                              │
│  阶段2: 设计确认 (Elena)                                                    │
│  ├── 生成设计规范 (颜色/字体/间距)                                          │
│  ├── 为每个功能生成设计稿                                                   │
│  ├── 渲染预览图                                                             │
│  └── 用户确认设计 ✓                                                         │
│                                                                              │
│  阶段3: 架构规划 (David + Sam)                                              │
│  ├── 技术选型                                                               │
│  ├── 目录结构                                                               │
│  ├── 数据库设计                                                             │
│  ├── 组件库定义                                                             │
│  └── 用户确认 ✓                                                             │
│                                                                              │
│  阶段4-6: 迭代开发 (循环)                                                   │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  迭代N:                                                              │   │
│  │  ├── 功能A: 契约→并行开发→Kevin测试→Mike验收                        │   │
│  │  ├── 功能B: 契约→并行开发→Kevin测试→Mike验收                        │   │
│  │  ├── 功能C: 契约→并行开发→Kevin测试→Mike验收                        │   │
│  │  ├── 集成测试                                                        │   │
│  │  ├── 用户旅程验收                                                    │   │
│  │  └── 用户确认 ✓                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  阶段7: 部署上线                                                            │
│  ├── 一键部署到Vercel                                                       │
│  ├── 配置域名                                                               │
│  ├── 设置监控                                                               │
│  └── 用户确认 ✓                                                             │
│                                                                              │
│  阶段8: 运维支持                                                            │
│  ├── 监控告警                                                               │
│  ├── 问题修复                                                               │
│  └── 持续优化                                                               │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════    │
│                                                                              │
│  知识积累: 项目完成后学习 → 更新模板库和错误库                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 十四、实现优先级

### Phase 1 (MVP) - 4周

```
必须实现:
├── Mike需求分析
├── 接口契约生成
├── 基于契约的代码生成 (David/Elena/Sam)
├── Kevin基础测试
├── 代码集成
└── 基础进度展示

可简化:
├── 设计确认 → 简单文字描述
├── UI验收 → 人工确认
├── 部署 → 手动导出代码
└── 知识库 → 暂无
```

### Phase 2 - 4周

```
增加:
├── Elena设计稿生成
├── 用户设计确认流程
├── Browser Use UI验收
├── 边界/异常测试
└── 一键部署
```

### Phase 3 - 4周

```
增加:
├── 知识库 (模板/错误案例)
├── 学习机制
├── 完整错误恢复
├── 人工介入机制
└── 监控运维
```

---

## 十五、技术依赖

```yaml
核心依赖:
  - E2B: 沙盒环境
  - Browser Use: 浏览器自动化
  - Claude API: AI能力
  - PostgreSQL: 数据库
  - Redis: 缓存/队列

可选依赖:
  - Vercel SDK: 部署
  - Sentry: 错误追踪
  - Stripe: 支付
```

---

## 十七、数据模型定义 (v11补充)

### 17.1 用户相关

```typescript
// User (用户)
interface IUser {
  _id: ObjectId
  email: string                    // 唯一
  name: string
  avatar?: string
  
  // 认证
  password?: string
  providers: Array<{
    provider: 'google' | 'github'
    providerId: string
  }>
  
  // 邀请相关
  invitedBy?: ObjectId
  invitationCode?: string
  
  // 设置
  settings: {
    language: 'zh' | 'en'
    theme: 'light' | 'dark' | 'system'
    notifications: {
      email: boolean
      push: boolean
      dailySummary: boolean
    }
  }
  
  status: 'active' | 'suspended' | 'deleted'
  createdAt: Date
  updatedAt: Date
}

// UserExecutive (用户专属高管)
interface IUserExecutive {
  _id: ObjectId
  userId: ObjectId
  agentId: AgentId              // mike, david, elena等
  
  // 学习到的偏好
  learnedPreferences: {
    communicationStyle?: 'formal' | 'casual' | 'concise' | 'detailed'
    focusAreas?: string[]
    decisionStyle?: 'fast' | 'careful' | 'data-driven'
  }
  
  // 记忆统计
  memoryStats: {
    totalMemories: number
    lastMemoryAt?: Date
  }
  
  createdAt: Date
  updatedAt: Date
}
```

### 17.2 项目相关

```typescript
// Project (项目)
interface IProject {
  _id: ObjectId
  userId: ObjectId
  
  name: string
  description: string
  
  // 项目阶段
  phase: 'ideation' | 'definition' | 'design' | 'development' | 'prelaunch' | 'growth'
  status: 'active' | 'paused' | 'completed' | 'archived'
  
  // 配置
  config: {
    techStack?: string[]
    targetPlatforms?: string[]
    businessModel?: string
  }
  
  // 进度
  progress: {
    completedMilestones: string[]
    currentTasks: string[]
    blockers: string[]
  }
  
  createdAt: Date
  updatedAt: Date
}

// Discussion (讨论)
interface IDiscussion {
  _id: ObjectId
  projectId: ObjectId
  userId: ObjectId
  
  topic: string
  participants: AgentId[]         // 参与的高管
  
  messages: Array<{
    role: 'user' | 'agent'
    agentId?: AgentId
    content: string
    timestamp: Date
  }>
  
  // 讨论结论
  conclusions?: Array<{
    type: 'decision' | 'action' | 'insight'
    content: string
    agentId: AgentId
  }>
  
  status: 'active' | 'concluded'
  createdAt: Date
}

// Decision (决策)
interface IDecision {
  _id: ObjectId
  projectId: ObjectId
  userId: ObjectId
  discussionId?: ObjectId
  
  title: string
  description: string
  options: Array<{
    id: string
    description: string
    pros: string[]
    cons: string[]
    recommendedBy: AgentId[]
  }>
  
  // 决策级别
  level: 'L0' | 'L1' | 'L2' | 'L3'
  
  // 状态
  status: 'pending' | 'approved' | 'rejected' | 'auto_approved'
  decidedAt?: Date
  decidedOption?: string
  
  // 超时自动处理
  autoApproveAt?: Date
  
  createdAt: Date
}
```

### 17.3 邀请和订阅

```typescript
// Waitlist (排队)
interface IWaitlist {
  _id: ObjectId
  email: string
  
  // 申请信息
  application: {
    projectIdea: string           // 想做什么项目
    role: string                  // 创业者/产品经理/开发者/学生
    referralSource?: string       // 从哪里得知
  }
  
  // 排队状态
  position: number                // 排队位置
  status: 'waiting' | 'approved' | 'rejected'
  
  // 审核
  reviewedAt?: Date
  reviewNote?: string
  
  createdAt: Date
}

// InvitationCode (邀请码)
interface IInvitationCode {
  _id: ObjectId
  code: string                    // 8位唯一码
  
  creatorId: ObjectId             // 创建者
  type: 'system' | 'user'         // 系统发放/用户邀请
  
  // 使用限制
  maxUses: number
  usedCount: number
  usedBy: ObjectId[]
  
  // 有效期
  expiresAt?: Date
  
  status: 'active' | 'exhausted' | 'expired' | 'revoked'
  createdAt: Date
}

// Subscription (订阅)
interface ISubscription {
  _id: ObjectId
  userId: ObjectId
  
  plan: 'free' | 'seed' | 'growth' | 'scale' | 'enterprise'
  
  // 配额
  limits: {
    projects: number              // 项目数量
    aiRequestsPerDay: number      // 每日AI请求
    storageGB: number             // 存储空间
    teamMembers: number           // 团队成员
  }
  
  // 计费
  billing: {
    amount: number
    currency: 'CNY' | 'USD'
    interval: 'monthly' | 'yearly'
    nextBillingAt?: Date
  }
  
  status: 'active' | 'cancelled' | 'past_due'
  startedAt: Date
  expiresAt?: Date
}
```

---

## 十八、全平台测试系统 (v12补充)

### 18.1 测试工具矩阵

```yaml
平台测试工具:
  Web:      Playwright (跨浏览器，微软官方)
  iOS:      Maestro + Detox (React Native友好)
  Android:  Maestro + Appium (成熟稳定)
  Windows:  WinAppDriver (微软官方)
  Mac:      Appium for Mac

运行环境:
  Web:      Docker容器
  iOS:      macOS / 云服务 (BrowserStack)
  Android:  Docker容器 (Android模拟器)
  Windows:  Windows VM
  Mac:      macOS
```

### 18.2 测试架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  AI生成代码 → TestOrchestrator → 分发到各平台Runner → 收集结果 → 分析      │
│                                                                              │
│  ┌─────────────┐                                                            │
│  │   Go层      │                                                            │
│  │ TestCoord   │  调度测试任务，收集结果，触发修复                          │
│  └──────┬──────┘                                                            │
│         │ gRPC                                                               │
│         ▼                                                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Python 测试执行层                               │   │
│  │                                                                      │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐              │   │
│  │  │WebRunner │ │iOSRunner │ │AndroidRun│ │WinRunner │              │   │
│  │  │Playwright│ │Maestro   │ │Appium    │ │WinAppDrv │              │   │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────┘              │   │
│  │                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 18.3 AI驱动的测试闭环

```python
# 核心类定义

class TestGenerator:
    """测试用例生成器"""
    
    async def generate(self, project_id: str) -> List[TestCase]:
        """基于代码和需求自动生成测试用例"""
        
        # 1. 分析代码结构
        code_structure = await self.analyze_code(project_id)
        
        # 2. 提取功能点
        features = await self.extract_features(code_structure)
        
        # 3. 为每个功能生成测试用例
        test_cases = []
        for feature in features:
            cases = await self._generate_cases_for_feature(feature)
            test_cases.extend(cases)
        
        return test_cases

class TestCase:
    """测试用例"""
    id: str
    name: str
    description: str
    steps: List[TestStep]
    expected_result: str
    platform: str  # web/ios/android/windows/mac
    priority: str  # P0/P1/P2

class TestStep:
    """测试步骤"""
    action: str      # click/fill/navigate/assert
    target: str      # 元素或页面
    value: str       # 输入值
    expected: str    # 期望结果

class TestResult:
    """测试结果"""
    case_id: str
    passed: bool
    actual_result: str
    screenshot: str
    error_message: str
    duration_ms: int

class ResultAnalyzer:
    """结果分析器"""
    
    async def analyze(self, results: Dict[str, List[TestResult]]) -> Analysis:
        """分析测试结果，找出问题"""
        
        failures = []
        for platform, platform_results in results.items():
            for result in platform_results:
                if not result.passed:
                    failures.append({
                        'platform': platform,
                        'case': result.case_id,
                        'error': result.error_message,
                        'screenshot': result.screenshot
                    })
        
        # AI分析失败原因
        if failures:
            root_causes = await self._analyze_root_causes(failures)
            return Analysis(has_failures=True, failures=failures, root_causes=root_causes)
        
        return Analysis(has_failures=False)

class TodoTracker:
    """TODO追踪器 (优化项2)"""
    
    async def scan(self, code: str) -> List[TodoItem]:
        """扫描代码中的TODO"""
        
        patterns = [
            r'//\s*TODO:?\s*(.+)',
            r'#\s*TODO:?\s*(.+)',
            r'/\*\s*TODO:?\s*(.+)\*/',
        ]
        
        todos = []
        for pattern in patterns:
            matches = re.findall(pattern, code)
            for match in matches:
                todos.append(TodoItem(content=match, status='pending'))
        
        return todos
    
    async def verify_all_done(self, project_id: str) -> bool:
        """验证所有TODO都已完成"""
        code = await self.get_project_code(project_id)
        todos = await self.scan(code)
        return len(todos) == 0

class TodoItem:
    content: str
    status: str  # pending/done
    file_path: str
    line_number: int

class ContextWindowMonitor:
    """上下文窗口监控器 (优化项4)"""
    
    def __init__(self, max_tokens: int = 100000):
        self.max_tokens = max_tokens
        self.warning_threshold = 0.7  # 70%时警告
        self.compress_threshold = 0.85  # 85%时压缩
    
    async def check(self, context: str) -> MonitorResult:
        """检查上下文大小"""
        
        current_tokens = self.count_tokens(context)
        usage_ratio = current_tokens / self.max_tokens
        
        if usage_ratio >= self.compress_threshold:
            return MonitorResult(
                action='compress',
                message=f'上下文已使用{usage_ratio:.0%}，需要压缩'
            )
        elif usage_ratio >= self.warning_threshold:
            return MonitorResult(
                action='warn',
                message=f'上下文已使用{usage_ratio:.0%}，接近上限'
            )
        
        return MonitorResult(action='ok')
    
    async def compress(self, context: str) -> str:
        """压缩上下文"""
        # 使用AI总结，保留关键信息
        summary = await self.ai.summarize(context)
        return summary

class BaseEmployee:
    """AI员工基类"""
    
    def __init__(self, employee_id: str, config: EmployeeConfig):
        self.employee_id = employee_id
        self.config = config
        self.memory_manager = MemoryManager(employee_id)
    
    async def chat(self, message: str, context: dict) -> str:
        """处理用户消息"""
        
        # 1. 检索相关记忆
        memories = await self.memory_manager.retrieve(message)
        
        # 2. 构建Prompt
        prompt = self._build_prompt(message, context, memories)
        
        # 3. 调用AI
        response = await self.ai.chat(prompt)
        
        # 4. 保存新记忆
        await self.memory_manager.save(message, response)
        
        return response
```

### 18.4 测试指标

```yaml
测试覆盖率目标:
  单元测试: >80%
  集成测试: >70%
  E2E测试:  核心流程100%

测试通过标准:
  Web:      Chrome/Firefox/Safari/Edge全部通过
  移动端:   iOS 15+, Android 10+ 通过
  桌面:     Windows 10+, macOS 12+ 通过
```

---

## 十九、项目生命周期 (v11补充)

### 19.1 六阶段定义

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  想法探索 → 需求定义 → 设计阶段 → 开发阶段 → 发布准备 → 增长运营           │
│  (1-2周)   (1-2周)    (1-3周)    (4-12周)   (1-2周)    (持续)               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 19.2 各阶段详情

```yaml
阶段1 - 想法探索 (Ideation):
  目标: 验证想法可行性
  核心高管: Mike(PM), Marcus(CMO)
  交付物: 可行性报告、市场分析
  
阶段2 - 需求定义 (Definition):
  目标: 明确产品范围
  核心高管: Mike(PM), David(Tech), Elena(UX)
  交付物: PRD、技术方案、原型草图
  
阶段3 - 设计阶段 (Design):
  目标: 完成产品设计
  核心高管: Elena(UX), David(Tech)
  交付物: 设计稿、技术架构、数据库设计
  
阶段4 - 开发阶段 (Development):
  目标: 完成产品开发
  核心高管: David(Tech), Kevin(QA), Frank(DevOps)
  交付物: 可运行的产品、测试报告
  
阶段5 - 发布准备 (Pre-launch):
  目标: 准备上线
  核心高管: Frank(DevOps), Grace(安全), Marcus(CMO)
  交付物: 部署完成、安全审计通过、营销素材
  
阶段6 - 增长运营 (Growth):
  目标: 持续优化
  核心高管: Marcus(CMO), Lisa(数据), Sarah(CFO)
  交付物: 运营报告、增长策略、财务分析
```

### 19.3 智能调度

```yaml
调度规则:
  1. 根据项目阶段自动配置核心高管
  2. 根据话题动态加入专家
  3. 成本优化的24小时自动运行

模型选择:
  核心分析: Claude Opus (重要决策)
  常规任务: Claude Sonnet (日常开发)
  调度分类: Claude Haiku (快速判断)
```

---

## 二十、CEO Dashboard (v11补充)

### 20.1 功能概述

```yaml
CEO Dashboard 是用户的控制中心，让用户像CEO一样管理AI团队:

核心功能:
  1. 项目总览: 所有项目状态、进度、关键指标
  2. 待处理决策: 需要用户确认的L2/L3决策
  3. 通知中心: 重要事项、进度更新、异常告警
  4. AI高管状态: 各高管当前任务和状态
  5. 财务概览: 成本、预算、订阅状态
  6. 快捷操作: 创建项目、发起讨论、查看报告
```

### 20.2 界面设计

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         CEO Dashboard                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │ 活跃项目: 3     │  │ 待处理决策: 2   │  │ 本月AI成本: ¥85 │             │
│  │ 进行中任务: 12  │  │ 紧急: 1        │  │ 预算剩余: 65%   │             │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘             │
│                                                                              │
│  【待处理决策】                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ ⚠️ [L2] 电商网站-技术选型确认                          还剩23小时   │   │
│  │    David建议使用Next.js + PostgreSQL                    [查看] [决定]│   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  【项目进度】                                                                │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ 📦 电商网站        设计阶段 ████████░░ 80%                          │   │
│  │ 📦 博客系统        开发阶段 ██████░░░░ 60%                          │   │
│  │ 📦 管理后台        想法探索 ██░░░░░░░░ 20%                          │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  【AI高管状态】                                                              │
│  Mike: 正在分析需求 | David: 代码审查中 | Elena: 设计稿制作               │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 二十一、技能蒸馏机制 (v11补充)

### 21.1 设计理念

```yaml
核心理念:
  - 用户专属高管的技能是私有的
  - 但优秀的通用技能可以匿名共享
  - 通过"蒸馏"提取通用知识，去除用户私有信息
  - 让所有用户都能从集体智慧中受益

蒸馏流程:
  1. 检测: 发现某高管解决问题的优秀模式
  2. 提取: 提取通用部分，去除用户特定信息
  3. 验证: 确保不包含隐私数据
  4. 分发: 推送给其他用户的同类高管
```

### 21.2 实现代码

```python
class SkillDistiller:
    """技能蒸馏器"""
    
    async def distill(self, agent_id: str, skill_pattern: SkillPattern) -> DistilledSkill:
        """蒸馏技能"""
        
        # 1. 提取通用知识
        generic_knowledge = await self._extract_generic(skill_pattern)
        
        # 2. 去除私有信息
        sanitized = await self._remove_private_info(generic_knowledge)
        
        # 3. 验证安全性
        if not await self._verify_safe(sanitized):
            return None
        
        # 4. 创建蒸馏技能
        return DistilledSkill(
            agent_type=agent_id,
            knowledge=sanitized,
            source_anonymous=True
        )
    
    async def distribute(self, skill: DistilledSkill):
        """分发到其他用户的高管"""
        
        # 找到所有同类型高管
        agents = await self.db.find_agents_by_type(skill.agent_type)
        
        # 推送更新（后台静默）
        for agent in agents:
            await self._inject_skill(agent, skill)
```

---

## 二十二、记忆进化机制 (v11补充)

### 22.1 记忆合并

```python
class MemoryEvolution:
    """记忆进化管理"""
    
    async def merge_similar_memories(self, user_id: str, agent_id: str):
        """合并相似记忆，减少冗余"""
        
        # 1. 获取所有记忆
        memories = await self.get_all_memories(user_id, agent_id)
        
        # 2. 聚类相似记忆
        clusters = await self._cluster_by_similarity(memories, threshold=0.85)
        
        # 3. 合并每个聚类
        for cluster in clusters:
            if len(cluster) > 1:
                merged = await self._merge_memories(cluster)
                await self._replace_with_merged(cluster, merged)
    
    async def _merge_memories(self, memories: List[Memory]) -> Memory:
        """合并多条记忆为一条"""
        
        prompt = f"""合并以下相关记忆为一条简洁的总结:

{[m.content for m in memories]}

要求:
1. 保留所有重要信息
2. 去除重复内容
3. 保持语义完整
"""
        
        merged_content = await self.ai.chat(prompt)
        
        return Memory(
            content=merged_content,
            merged_from=[m.id for m in memories],
            importance=max(m.importance for m in memories)
        )
```

### 22.2 记忆遗忘

```python
async def forget_outdated(self, user_id: str, agent_id: str):
    """遗忘过时的记忆"""
    
    # 1. 找出长期未被检索的记忆
    unused_memories = await self.find_unused_memories(
        user_id, agent_id,
        unused_days=90  # 90天未使用
    )
    
    # 2. 降低其重要性
    for memory in unused_memories:
        memory.importance *= 0.5
        
        # 重要性过低则删除
        if memory.importance < 0.1:
            await self.delete_memory(memory.id)
        else:
            await self.update_memory(memory)

async def forget_contradicted(self, user_id: str, agent_id: str, new_info: str):
    """遗忘被新信息否定的旧记忆"""
    
    # 1. 找出可能冲突的旧记忆
    old_memories = await self.search_related(user_id, agent_id, new_info)
    
    # 2. 检测冲突
    for memory in old_memories:
        if await self._is_contradicted(memory.content, new_info):
            # 标记为过时，降低权重
            memory.status = 'outdated'
            memory.importance *= 0.1
            await self.update_memory(memory)
```

---

## 二十三、API设计概览 (v11补充)

### 23.1 核心Router

```typescript
// API路由设计

// 用户相关
POST   /api/auth/register          // 注册
POST   /api/auth/login             // 登录
GET    /api/users/me               // 获取当前用户
PATCH  /api/users/me               // 更新用户信息

// 项目相关
GET    /api/projects               // 项目列表
POST   /api/projects               // 创建项目
GET    /api/projects/:id           // 项目详情
PATCH  /api/projects/:id           // 更新项目
DELETE /api/projects/:id           // 删除项目
POST   /api/projects/:id/phase     // 推进阶段

// AI讨论
GET    /api/projects/:id/discussions           // 讨论列表
POST   /api/projects/:id/discussions           // 创建讨论
GET    /api/discussions/:id                    // 讨论详情
POST   /api/discussions/:id/messages           // 发送消息
POST   /api/discussions/:id/conclude           // 结束讨论

// 决策
GET    /api/projects/:id/decisions             // 决策列表
GET    /api/decisions/:id                      // 决策详情
POST   /api/decisions/:id/approve              // 批准决策
POST   /api/decisions/:id/reject               // 拒绝决策

// AI高管
GET    /api/agents                             // 高管列表
GET    /api/agents/:id                         // 高管详情
GET    /api/agents/:id/memories                // 高管记忆
PATCH  /api/agents/:id/preferences             // 更新偏好

// 邀请
POST   /api/waitlist                           // 加入等待列表
GET    /api/invitations                        // 我的邀请码
POST   /api/invitations/verify                 // 验证邀请码

// 订阅
GET    /api/subscriptions/current              // 当前订阅
POST   /api/subscriptions                      // 创建订阅
POST   /api/subscriptions/cancel               // 取消订阅

// WebSocket
WS     /ws/projects/:id                        // 项目实时更新
WS     /ws/discussions/:id                     // 讨论实时消息
```

### 23.2 tRPC定义 (可选)

```typescript
// 使用tRPC的类型安全API

export const appRouter = router({
  // 项目
  project: router({
    list: publicProcedure.query(async ({ ctx }) => {
      return ctx.db.project.findMany({ where: { userId: ctx.userId } })
    }),
    create: publicProcedure
      .input(z.object({ name: z.string(), description: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return ctx.db.project.create({ data: { ...input, userId: ctx.userId } })
      }),
  }),
  
  // AI讨论
  discussion: router({
    send: publicProcedure
      .input(z.object({ discussionId: z.string(), message: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // 发送消息给AI高管
        return ctx.ai.chat(input.discussionId, input.message)
      }),
  }),
})
```

### 20.1 基础Prompt结构

```markdown
## 角色
你是{name}，Thinkus的{title}。

## 背景
{background}

## 性格特点
{personality}

## 专业技能
{skills}

## 对话风格
{style}

## 历史记忆
{memories}

## 当前项目上下文
{project_context}

## 工作原则
1. 始终站在用户利益角度思考
2. 给出具体可执行的建议
3. 适时与其他高管协作
```

### 20.2 运行时注入

```python
def build_prompt(agent: Agent, context: Context, memories: List[Memory]) -> str:
    """构建完整Prompt"""
    
    # 基础模板
    base = load_template(agent.id)
    
    # 注入记忆
    memory_text = format_memories(memories)
    
    # 注入项目上下文
    project_text = format_project(context.project)
    
    # 注入当前讨论上下文
    discussion_text = format_discussion(context.discussion)
    
    return f"""
{base}

## 历史记忆
{memory_text}

## 当前项目
{project_text}

## 当前讨论
{discussion_text}
"""
```

---

## 二十一、关键成功指标汇总

```yaml
产品指标:
  - 项目完成率: > 95%
  - 用户满意度: NPS > 50
  - 一次通过率: > 80%
  - 测试覆盖率: > 90%

商业指标:
  - 免费→付费转化: > 5%
  - 用户留存 (D30): > 25%
  - ARPU: > ¥200/月

增长指标:
  - 邀请发送率: > 40%
  - 邀请转化率: > 30%
  - 病毒系数K: > 0.7

技术指标:
  - API响应时间: < 200ms
  - 系统可用性: > 99.9%
  - AI响应时间: < 5s
```
