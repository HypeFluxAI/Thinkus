# 01 系统架构

## 1. 整体架构

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Thinkus v12 架构                               │
│                        Node.js + Go + Python 三层                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                           前端 (Next.js) ✅现有                         │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                     │ REST / WebSocket                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                      Node.js API层 ✅现有                               │ │
│  │   用户认证 │ 项目CRUD │ 文件管理 │ WebSocket │ Stripe │ 版本管理      │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                     │ gRPC                                   │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                        Go 编排层 🆕新增                                 │ │
│  │   任务调度 │ 工作流引擎 │ 检查点管理 │ 防摸鱼 │ 容器编排              │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                     │ gRPC                                   │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                       Python AI层 🆕新增                                │ │
│  │   AI员工 │ CodeIndexer │ PromptBuilder │ TaskDecomposer │ AutoVerify  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                     │ Docker API                             │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                          沙盒容器                                       │ │
│  │                    Claude Code / Codex 执行                             │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                      数据层 ✅现有                                      │ │
│  │              PostgreSQL │ Redis │ S3                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. 三层职责

| 层 | 技术 | 职责 | 状态 |
|----|------|------|------|
| **API层** | Node.js | 用户认证、项目CRUD、文件管理、WebSocket、支付 | ✅现有 |
| **编排层** | Go | 任务调度、工作流、检查点、容器管理 | 🆕新增 |
| **AI层** | Python | AI员工、上下文管理、代码执行、验证 | 🆕新增 |

### 详细职责

```
Node.js (保留现有代码):
├── 用户认证 (JWT/OAuth)
├── 项目CRUD
├── 文件上传/管理
├── WebSocket实时通信
├── 版本管理
├── Stripe支付
├── GitHub OAuth
└── 新增: gRPC调用Go层

Go (新增):
├── 任务调度器 (Scheduler)
├── 工作流引擎 (Workflow)
├── 检查点管理 (Checkpoint)
├── 防摸鱼机制 (AntiSlacking)
└── Docker容器管理

Python (新增):
├── AI员工引擎
├── CodeIndexer (代码索引)
├── PromptBuilder (Prompt构建)
├── TaskDecomposer (任务分解)
└── Auto-Verify (自动验证)
```

---

## 3. 目录结构

```
thinkus-v12/
├── apps/
│   ├── web/                     # Next.js前端 ✅现有
│   ├── api/                     # Node.js API ✅现有
│   │   └── src/
│   │       ├── grpc/           # 🆕 gRPC客户端
│   │       └── ...             # 现有代码
│   ├── orchestrator/            # Go编排服务 🆕新增
│   └── ai-service/              # Python AI服务 🆕新增
│
├── packages/                     # 共享包 ✅现有
│
├── internal/                     # Go模块 🆕新增
│   ├── scheduler/
│   ├── workflow/
│   ├── checkpoint/
│   └── container/
│
├── services/                     # Python模块 🆕新增
│   ├── ai_employees/
│   ├── context_manager/
│   ├── code_executor/
│   └── auto_verify/
│
├── proto/                        # gRPC定义 🆕新增
│   ├── orchestrator.proto
│   └── ai_service.proto
│
└── docker/
    ├── Dockerfile.api           # Node.js
    ├── Dockerfile.orchestrator  # Go 🆕
    ├── Dockerfile.ai            # Python 🆕
    └── sandbox/
```

---

## 4. Node.js扩展 (对接Go层)

### 4.1 gRPC客户端

```typescript
// apps/api/src/grpc/orchestrator.client.ts
import * as grpc from '@grpc/grpc-js';
import * as protoLoader from '@grpc/proto-loader';

const packageDefinition = protoLoader.loadSync('../../proto/orchestrator.proto');
const proto = grpc.loadPackageDefinition(packageDefinition) as any;

class OrchestratorClient {
  private client: any;

  constructor() {
    this.client = new proto.orchestrator.OrchestratorService(
      process.env.ORCHESTRATOR_URL || 'localhost:50050',
      grpc.credentials.createInsecure()
    );
  }

  async submitTask(projectId: string, requirement: string) {
    return new Promise((resolve, reject) => {
      this.client.SubmitTask({ projectId, requirement }, (err, res) => {
        err ? reject(err) : resolve(res);
      });
    });
  }

  async getTaskStatus(taskId: string) {
    return new Promise((resolve, reject) => {
      this.client.GetTaskStatus({ taskId }, (err, res) => {
        err ? reject(err) : resolve(res);
      });
    });
  }

  subscribeEvents(projectId: string) {
    return this.client.SubscribeEvents({ projectId });
  }
}

export const orchestratorClient = new OrchestratorClient();
```

### 4.2 扩展Controller

```typescript
// apps/api/src/controllers/project.controller.ts
import { orchestratorClient } from '../grpc/orchestrator.client';

export class ProjectController {
  // ... 现有方法保持不变 ...

  // 🆕 提交开发任务
  async submitTask(req: Request, res: Response) {
    const { projectId } = req.params;
    const { requirement } = req.body;

    // 1. 权限验证 (现有逻辑)
    const project = await this.projectService.findById(projectId);
    if (project.userId !== req.user.id) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    // 2. 调用Go编排层
    const task = await orchestratorClient.submitTask(projectId, requirement);

    // 3. 记录任务 (现有数据库)
    await this.taskService.create({
      id: task.taskId,
      projectId,
      requirement,
      status: 'pending',
    });

    return res.json(task);
  }
}
```

### 4.3 WebSocket转发

```typescript
// apps/api/src/websocket/project.gateway.ts
export class ProjectGateway {
  setupOrchestratorStream(projectId: string, socket: Socket) {
    const stream = orchestratorClient.subscribeEvents(projectId);

    stream.on('data', (event) => {
      socket.emit(event.type, JSON.parse(event.payload));
    });

    socket.on('disconnect', () => stream.cancel());
  }
}
```

---

## 5. Go编排层

### 5.1 gRPC定义

```protobuf
// proto/orchestrator.proto
syntax = "proto3";
package orchestrator;

service OrchestratorService {
  rpc SubmitTask(SubmitTaskRequest) returns (SubmitTaskResponse);
  rpc GetTaskStatus(TaskStatusRequest) returns (TaskStatusResponse);
  rpc StopTask(StopTaskRequest) returns (StopTaskResponse);
  rpc SubscribeEvents(SubscribeRequest) returns (stream Event);
}

message SubmitTaskRequest {
  string project_id = 1;
  string requirement = 2;
}

message SubmitTaskResponse {
  string task_id = 1;
  int32 estimated_minutes = 2;
}

message Event {
  string type = 1;    // ai_response, code_updated, task_progress
  string payload = 2; // JSON
}
```

### 5.2 任务调度器

```go
// internal/scheduler/scheduler.go
package scheduler

type Task struct {
    ID          string
    ProjectID   string
    Requirement string
    Status      string // pending, planning, executing, verifying, completed, failed
    SubTasks    []*SubTask
}

type Scheduler struct {
    tasks    map[string]*Task
    aiClient pb.AIServiceClient
}

func (s *Scheduler) SubmitTask(ctx context.Context, projectID, requirement string) (*Task, error) {
    task := &Task{
        ID:          generateID(),
        ProjectID:   projectID,
        Requirement: requirement,
        Status:      "pending",
    }
    s.tasks[task.ID] = task
    
    go s.executeTask(ctx, task)
    return task, nil
}

func (s *Scheduler) executeTask(ctx context.Context, task *Task) {
    // 1. 规划
    task.Status = "planning"
    planResp, _ := s.aiClient.Plan(ctx, &pb.PlanRequest{
        ProjectId:   task.ProjectID,
        Requirement: task.Requirement,
    })
    task.SubTasks = planResp.Tasks
    
    // 2. 执行子任务
    task.Status = "executing"
    for _, subTask := range task.SubTasks {
        // 生成代码
        codeResp, _ := s.aiClient.GenerateCode(ctx, &pb.CodeRequest{
            ProjectId:       task.ProjectID,
            TaskDescription: subTask.Description,
        })
        
        // 验证
        verifyResp, _ := s.aiClient.Verify(ctx, &pb.VerifyRequest{
            ProjectId:    task.ProjectID,
            FilesToCheck: codeResp.FilesModified,
        })
        
        if !verifyResp.Success {
            // 重试...
        }
    }
    
    task.Status = "completed"
}
```

### 5.3 检查点管理

```go
// internal/checkpoint/manager.go
type Checkpoint struct {
    ID         string
    ProjectID  string
    Phase      string // requirements, foundation, core_features, delivery
    SnapshotID string
    Evaluation *Evaluation
}

type Evaluation struct {
    DeviationScore float64 // 0-100
}

type CheckpointManager struct {
    store     CheckpointStore
    snapshots SnapshotService
}

func (m *CheckpointManager) Create(projectID, phase string) (*Checkpoint, error) {
    snapshotID, _ := m.snapshots.Create(projectID)
    return &Checkpoint{
        ID:         generateID(),
        ProjectID:  projectID,
        Phase:      phase,
        SnapshotID: snapshotID,
    }, nil
}

func (m *CheckpointManager) Evaluate(cp *Checkpoint) string {
    switch {
    case cp.Evaluation.DeviationScore < 20:
        return "pass"    // 继续
    case cp.Evaluation.DeviationScore < 50:
        return "revise"  // 返工
    default:
        return "restart" // 重启
    }
}

func (m *CheckpointManager) Rollback(cp *Checkpoint) error {
    return m.snapshots.Restore(cp.ProjectID, cp.SnapshotID)
}
```

---

## 6. Python AI层

### 6.1 gRPC服务

```python
# services/grpc_server.py
class AIServicer(ai_service_pb2_grpc.AIServiceServicer):
    
    def __init__(self):
        self.ai_engine = AIEmployeeEngine()
        self.verifier = AutoVerifier()
    
    def Plan(self, request, context):
        """任务规划"""
        indexer = CodeIndexer(f"/workspaces/{request.project_id}")
        indexer.build_index()
        
        decomposer = TaskDecomposer(indexer, self.ai_engine)
        tasks = decomposer.decompose(request.requirement)
        
        return ai_service_pb2.PlanResponse(tasks=[...])
    
    def GenerateCode(self, request, context):
        """代码生成"""
        project_path = f"/workspaces/{request.project_id}"
        
        indexer = CodeIndexer(project_path)
        indexer.load_index()
        
        relevant_files = indexer.get_relevant_files(request.task_description)
        
        builder = PromptBuilder(indexer, project_path)
        prompt = builder.build(request.task_id, request.task_description, relevant_files)
        
        executor = CodeExecutor(project_path)
        result = executor.execute(prompt)
        
        return ai_service_pb2.CodeResponse(
            success=result.success,
            files_modified=result.files_modified
        )
    
    def Verify(self, request, context):
        """验证代码"""
        result = self.verifier.verify(
            f"/workspaces/{request.project_id}",
            list(request.files_to_check)
        )
        return ai_service_pb2.VerifyResponse(
            success=result.success,
            build_passed=result.build_passed,
            tests_passed=result.tests_passed
        )
```

---

## 7. 通信流程

```
用户: "帮我做一个任务管理工具"

前端 ──REST──> Node.js ──gRPC──> Go ──gRPC──> Python
                                  │
                                  ├─> Plan (规划)
                                  │     └─> 返回任务列表
                                  │
                                  ├─> 循环执行:
                                  │     ├─> GenerateCode (生成代码)
                                  │     └─> Verify (验证)
                                  │
                                  └─> 事件推送 (WebSocket)
                                        ├─> ai_response
                                        ├─> code_updated
                                        └─> task_progress

前端 <══WS══ Node.js <══Stream══ Go
```

---

## 8. 部署配置

```yaml
# docker-compose.yml
services:
  web:
    build: ./apps/web
    ports: ["3001:3000"]

  api:  # Node.js ✅现有
    build: ./apps/api
    ports: ["3000:3000"]
    environment:
      - DATABASE_URL=postgres://...
      - ORCHESTRATOR_URL=orchestrator:50050
    depends_on: [db, redis, orchestrator]

  orchestrator:  # Go 🆕新增
    build:
      dockerfile: docker/Dockerfile.orchestrator
    ports: ["50050:50050"]
    environment:
      - AI_SERVICE_URL=ai-service:50051
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - project-data:/workspaces

  ai-service:  # Python 🆕新增
    build:
      dockerfile: docker/Dockerfile.ai
    ports: ["50051:50051"]
    environment:
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
    volumes:
      - project-data:/workspaces

  db:
    image: postgres:15

  redis:
    image: redis:7-alpine

volumes:
  project-data:
```

---

## 9. 端口规划

| 服务 | 端口 | 协议 |
|------|------|------|
| Web前端 | 3001 | HTTP |
| Node.js API | 3000 | HTTP/WS |
| Go编排层 | 50050 | gRPC |
| Python AI层 | 50051 | gRPC |
| PostgreSQL | 5432 | TCP |
| Redis | 6379 | TCP |

---

## 10. 迁移计划

```
Week 1-2: 部署Go/Python，Node.js通过flag切换
Week 3-4: 新功能走Go+Python，旧功能保持
Week 5+:  全量切换，优化性能
```
